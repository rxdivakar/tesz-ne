// const userPool = require("../congnito");
// const AmazonCognitoIdentity = require("amazon-cognito-identity-js");
const pool = require("../../database");
const { v4: uuidv4 } = require("uuid");

//create tenant
module.exports.createTenantTable = async function (req, res) {
  const createTenantTableQuery = `create table tenant (
    tenant_id VARCHAR(100) NOT NULL UNIQUE ,
    tenant_fullname VARCHAR(250) NOT NULL,
    tenant_displayname VARCHAR(250) NOT NULL,
    tenant_email VARCHAR(250) NOT NULL UNIQUE,
    tenant_country VARCHAR(250) NOT NULL,
    tenant_phone VARCHAR(250) NOT NULL,
    is_active BOOLEAN,
    CONSTRAINT tenantadminref PRIMARY KEY (tenant_id)
    )`;

  try {
    await pool.query(createTenantTableQuery);
    res.send("Tenant table created successfully");
  } catch (error) {
    console.log(error, "something went wrong,please try again later");
  }
};

//tenant entries
module.exports.tenantEntry = async function (req, res) {

  const {
    tenant_fullname,
    tenant_displayname,
    tenant_email,
    tenant_country,
    tenant_phone,
    is_active,
   } = req.body;

  let tenant_id = uuidv4();

  const findTenantByEmail = `select * from tenant where tenant_email = '${tenant_email}'`;
  try {
    let user = await pool.query(findTenantByEmail);

    if (user.rows.length > 0) {
      return res.status(403).json({ error: [{ msg: "user already present" }] });
    }
    const { rows } = await pool.query(`insert into tenant values(
    '${tenant_id}',
    '${tenant_fullname}', 
    '${tenant_displayname}', 
    '${tenant_email}',
    '${tenant_country}',
    '${tenant_phone}',
    '${is_active}') RETURNING *`);

    res
      .status(200)
      .json({ data: [rows[0]], message: "tenant created successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenant creation failed" });
  }
};

//get all tenants details
module.exports.getAllTenants = async function (req, res) {
  const findAllTenant = `select * from tenant`;
  try {
    const { rows } = await pool.query(findAllTenant);
    res
      .status(200)
      .json({ data: rows, message: "All Tenants fetched successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenant creation failed" });
  }
};

//TODO
//get subscription by tenant ID
module.exports.getAllSubscriptionBytenants = async function (req, res) {
  const findAllTenant = `select t1.tenant_id,t1.tenant_fullname,t1.tenant_displayname,t1.tenant_email,
  t1.tenant_country,t1.tenant_phone,t1.is_active,
  Json_build_object('tenantAdmin_id',t2.tenantAdmin_id,
    'tenantAdmin_fullname',t2.tenantAdmin_fullname,
    'tenantAdmin_displayname',t2.tenantAdmin_displayname,
    'tenantAdmin_designation',t2.tenantAdmin_designation,
    'tenantAdmin_email',t2.tenantAdmin_email,
    'tenantAdmin_country',t2.tenantAdmin_country,
    'tenantAdmin_phone',t2.tenantAdmin_phone) as tenantadmin_id,
  Json_build_object('subscription_tenant_id',t3.subscription_tenant_id,
				     'subscription_id',t3.subscription_id,
				     'is_active',t3.is_active,
				      'start_date',t3.start_date,
				      'end-date',t3.end_date) as subscription_id
  from tenant t1
  inner join tenantadmin t2 on t2.tenant_id =t1.tenant_id
  inner join  subtenant t3 on t3.tenant_id = t1.tenant_id`;
  try {
    const data = await pool.query(findAllTenant);
    const proDetails = data.rows;
    res
      .status(200)
      .json({ data: [proDetails], message: "All Tenants fetched successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenant creation failed" });
  }
};

//get tenant details by id

module.exports.getTenantById = async function (req, res) {
  const tid = req.params.tenant_id;
  const findTenant = `select t1.tenant_id,t1.tenant_fullname,t1.tenant_displayname,t1.tenant_email,
  t1.tenant_country,t1.tenant_phone,t1.is_active,
  Json_build_object('tenantAdmin_id',t2.tenantAdmin_id,
    'tenantAdmin_fullname',t2.tenantAdmin_fullname,
    'tenantAdmin_displayname',t2.tenantAdmin_displayname,
    'tenantAdmin_designation',t2.tenantAdmin_designation,
    'tenantAdmin_email',t2.tenantAdmin_email,
    'tenantAdmin_country',t2.tenantAdmin_country,
    'tenantAdmin_phone',t2.tenantAdmin_phone) as tenantadmin_id,
   Json_build_object('subscription_tenant_id',t3.subscription_tenant_id,
	  'subscription_id',t3.subscription_id,
		'is_active',t3.is_active,
		'start_date',t3.start_date,
		'end-date',t3.end_date) as subscription_id
  from tenant t1
  inner join tenantadmin t2 on t2.tenant_id =t1.tenant_id
  inner join subtenant t3 on t3.tenant_id = t1.tenant_id where t1.tenant_id='${tid}'`
  try {
    const tenantUser = await pool.query(findTenant)
    if (!tenantUser.rows.length > 0) {
      return res.status(404).json({ error: [{ msg: "customer not exist" }] });
    }
    const tenantDetails = tenantUser.rows[0];

    res.status(200).json({ data: [tenantDetails], message: "customer fetched successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "customer creation failed" });
  }
};

// update tenant details

module.exports.updateTenant = async function (req, res) {
  const tid = req.params.tenant_id;

  const { tenant_fullname,
    tenant_displayname,
    tenant_country,
    tenant_phone,
    is_active } = req.body;

  const updatenant = `update tenant set tenant_fullname ='${tenant_fullname}',tenant_displayname ='${tenant_displayname}',tenant_country='${tenant_country}',tenant_phone='${tenant_phone}',is_active='${is_active}' where tenant_id ='${tid}' RETURNING *`;

  const findTenant = `select * from tenant where tenant_id ='${tid}'`;
  try {
    const tenantUser = await pool.query(findTenant);

    if (!tenantUser.rows.length > 0) {
      return res.status(404).json({ error: [{ msg: "customer not exist" }] });
    }
    const updatedTenant = await pool.query(updatenant)

    const updatedList = updatedTenant.rows[0]
    res.status(200).json({
      data: [req.body, req.params.tenant_id, updatedList],
      message: "tenant updated successfully"
    });

  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenant updation failed" });
  }
};

//delete tenant deatils 

module.exports.deleteTenant = async function (req, res) {
  const tid = req.params.tenant_id
  const findTenant = `select * from tenant where tenant_id ='${tid}'`;
  const deleteTenant = `delete from tenant where tenant_id ='${tid}'`;

  try {
    const tenantUser = await pool.query(findTenant);
    if (!tenantUser.rows.length > 0) {
      return res.status(404).json({ error: [{ msg: "customer not exist" }] });
    }
    await pool.query(deleteTenant);

    res.status(200).json({data: [{deleted_id:req.params.tenant_id}],message: "customer deleted successfully"});
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenant deletion failed" });
  }
};
