// const userPool = require("../congnito");
// const AmazonCognitoIdentity = require("amazon-cognito-identity-js");
const pool = require("../../database");
const { v4: uuidv4 } = require("uuid");

//product entries
module.exports.productEntry = async function (req, res) {
  let { product_name, product_desc, product_price, is_active } = req.body;
  const findUserByPid = `select * from product where product_name ='${product_name}'`;
  try {
    let user = await pool.query(findUserByPid);

    if (user.rows.length > 0) {
      return res.status(403).json({ error: [{ msg: "user already present" }] });
    }
    let product_id = uuidv4();
    const insertData = `insert into product values(
      '${product_id}',
      '${product_name}', 
      '${product_desc}', 
      '${product_price}',
      '${is_active}') RETURNING *`;

    const resp = await pool.query(insertData);
    res
      .status(200)
      .json({ data: [resp.rows[0]], message: "product created successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "product creation failed" });
  }
};

//get all details from product table
module.exports.getAllProducts = async function (req, res) {
  const findAllProduct = `SELECT
    p.product_id,
    p.product_name,
    p.product_desc,
    p.product_price,
    p.is_active,
    COALESCE(
        Jsonb_agg(DISTINCT Jsonb_build_object('module_id', m.module_id, 'module_name', m.module_name)) FILTER (WHERE m.product_id IS NOT NULL),
        '[]'::jsonb
    ) AS modules
FROM
    product p
LEFT JOIN
    module m ON p.product_id = m.product_id
GROUP BY
    p.product_id, p.product_name, p.product_desc, p.product_price, p.is_active;`;

  try {
    const data = await pool.query(findAllProduct);
    const proDetails = data.rows;
    res.status(200).json({
      data: proDetails,
      message: "All Products fetched successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "product creation failed" });
  }
};

// get product details by productid
module.exports.getProductById = async function (req, res) {
  const pid = req.params.product_id;

  const findProByid = `SELECT 
  p.*,
  COALESCE(json_agg(m) FILTER (WHERE m.module_id IS NOT NULL), '[]') AS modules
FROM 
  product p
LEFT JOIN 
  module m ON p.product_id = m.product_id
WHERE 
  p.product_id = '${pid}'
GROUP BY 
  p.product_id;`;

  try {
    const user = await pool.query(findProByid);
    if (!user.rows.length > 0) {
      return res
        .status(404)
        .json({
          error: [{ msg: "Product not exist" }],
          message: "Product not exist"
        });
    }
    const proDetails = user.rows[0];
    res
      .status(200)
      .json({ data: [proDetails], message: "Product fetched successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "product fetch failed" });
  }
};

// get tenant details by productID
module.exports.getTenantProductById = async function (req, res) {
  const pid = req.params.product_id;

  const findProByid = `WITH ProductDetails AS (
    SELECT
        t1.product_id,
        t1.product_name,
        t1.product_desc,
        t1.product_price,
        t1.is_active
    FROM
        product t1
    WHERE
        t1.product_id = '${pid}'
)
SELECT
    pd.product_id,
    pd.product_name,
    pd.product_desc,
    pd.product_price,
    pd.is_active,
    COUNT(t.tenant_id) AS total_tenant_count,
    COUNT(CASE WHEN t.is_active = true THEN 1 END) AS active_tenant_count,
    COUNT(CASE WHEN t.is_active = false THEN 1 END) AS inactive_tenant_count,
    COALESCE(
        JSONB_AGG(JSONB_BUILD_OBJECT(
            'tenant_id', t.tenant_id,
            'tenant_fullname', t.tenant_fullname,
            'is_active', t.is_active
        )), '[]'::JSONB
    ) AS tenant_details
FROM
    ProductDetails pd
JOIN
    subscription s ON pd.product_id = ANY(CAST((s.products::uuid[]) AS VARCHAR[]))
JOIN
    subtenant ts ON s.subscription_id = ts.subscription_id
JOIN
    tenant t ON ts.tenant_id = t.tenant_id
GROUP BY
    pd.product_id,
    pd.product_name,
    pd.product_desc,
    pd.product_price,
    pd.is_active;`;

  try {
    const user = await pool.query(findProByid);
    if (!user.rows.length > 0) {
      return res.status(404).json({ error: [{ msg: "user not exist" }] });
    }
    const proDetails = user.rows[0];
    res
      .status(200)
      .json({ data: [proDetails], message: "Product fetched successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "product creation failed" });
  }
};

//update products
module.exports.updateProduct = async function (req, res) {
  const pid = req.params.product_id;
  const { product_name, product_desc, product_price, is_active } = req.body;
  const updateproduct = `update product set product_name ='${product_name}',product_desc ='${product_desc}',product_price ='${product_price}',
  is_active='${is_active}' where product_id ='${pid}' RETURNING *`;
  const findProductById = `select * from product where product_id='${pid}'`;

  try {
    const findProduct = await pool.query(findProductById);
    if (!findProduct.rows.length > 0) {
      return res.status(404).json({ error: [{ msg: "user not exist" }] });
    }
    const user = await pool.query(updateproduct);
    const updatedetails = user.rows[0];
    res
      .status(200)
      .json({ data: [updatedetails], message: "product updated successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "product updation failed" });
  }
};
//delete product
module.exports.deleteProduct = async function (req, res) {
  const pid = req.params.product_id;

  try {
    const checkModules = `SELECT * FROM module WHERE product_id = '${pid}'`;
    const modules = await pool.query(checkModules);

    if (modules.rows.length > 0) {
      return res.status(400).json({
        error: { detail: "Delete Product's Modules and try again" },
        message: "Product deletion failed"
      });
    }
    const deleteProductQuery = `DELETE FROM product WHERE product_id ='${pid}'`;
    await pool.query(deleteProductQuery);

    res.status(200).json({
      data: [{ deleted_id: req.params.product_id }],
      message: "Product deleted successfully"
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error, message: "Product deletion failed" });
  }
};