// const userPool = require("../congnito");
// const AmazonCognitoIdentity = require("amazon-cognito-identity-js");
const pool = require("../../database");
const { v4: uuidv4 } = require("uuid");

//create module table
module.exports.createModuleTable = async function (req, res) {
  const createModuleTableQuery = `create table module (
    product_id VARCHAR(150) NOT NULL,
    module_id VARCHAR(100000) NOT NULL UNIQUE,
    module_name VARCHAR(10000) NOT NULL UNIQUE,
    module_desc VARCHAR(10000),
    module_price VARCHAR(10000) NOT NULL,
    is_active BOOLEAN,
    module_permissions json NOT NULL,
    CONSTRAINT product_ref FOREIGN KEY (product_id) REFERENCES product(product_id)
    )`;

  try {
    await pool.query(createModuleTableQuery);
    res.send("Module table created successfully");
  } catch (error) {
    console.log(error, "something went wrong,please try again later");
  }
};
//module entries
module.exports.moduleEntry = async function (req, res) {
  let { product_id, module_name, module_desc, module_price, is_active } =
    req.body;
  const findUserByPid = `select * from module where module_name ='${module_name}'`;
  try {
    let user = await pool.query(findUserByPid);

    if (user.rows.length > 0) {
      return res.status(403).json({ error: [{ msg: "user already present" }] });
    }

    const createPermission = (name) => {
      const convertToUpperCaseWithUnderscores = (str) => {
        return str
          .split(" ")
          .map((word) => word.toUpperCase())
          .join("_");
      };

      let mod_name = convertToUpperCaseWithUnderscores(name);
      let resultArr = [];
      let actions = ["VIEW", "EDIT", "CREATE", "DELETE"];
      actions.forEach((item) => {
        resultArr.push(`${mod_name}_${item}`);
      });
      return resultArr;
    };

    let module_permissions = createPermission(module_name);
    module_permissions = JSON.stringify(module_permissions);
    let module_id = uuidv4();
    const insertData = `insert into module values(
      '${product_id}',
      '${module_id}',
      '${module_name}',
      '${module_desc}',
      '${module_price}',
      '${is_active}',
      '${module_permissions}') RETURNING *`;

    const resp = await pool.query(insertData);
    res
      .status(200)
      .json({ data: [resp.rows[0]], message: "module created successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "module creation failed" });
  }
};

//get all details from module table
module.exports.getAllModules = async function (req, res) {
  //TODO: should fetch all modules along with their respective products

  const findAllModule = `select Json_build_object('product_id',p.product_id,'product_name',p.product_name,'product_desc',p.product_desc,'product_price',p.product_price,'is_active',p.is_active) AS product_data,m.product_id,m.module_id,m.module_name,m.module_desc,m.module_price,m.is_active FROM module m inner join product p ON m.product_id = p.product_id`;

  try {
    const data = await pool.query(findAllModule);
    const proDetails = data.rows;
    res
      .status(200)
      .json({ data: proDetails, message: "All Modules fetched successfully" });
  } catch (error) {
    console.log(error, "<---------------this");
    res.status(500).json({ error: error, message: "module creation failed" });
  }
};

// get module details by moduleid
module.exports.getModuleById = async function (req, res) {
  //TODO: should fetch module by id along with their respective product

  const pid = req.params.module_id;
  const findProByid = `select * from module where module_id ='${pid}'`;

  try {
    const user = await pool.query(findProByid);
    if (!user.rows.length > 0) {
      return res.status(404).json({ error: [{ msg: "user not exist" }] });
    }
    const proDetails = user.rows[0];
    res
      .status(200)
      .json({ data: [proDetails], message: "Module fetched successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "module creation failed" });
  }
};

//update modules
module.exports.updateModule = async function (req, res) {
  const pid = req.params.module_id;
  const { module_name, module_desc, module_price, is_active } = req.body;
  const updatemodule = `update module set module_name ='${module_name}',module_desc ='${module_desc}',module_price ='${module_price}',
  is_active='${is_active}' where module_id ='${pid}' RETURNING *`;
  const findModuleById = `select * from module where module_id='${pid}'`;

  try {
    const moduleUser = await pool.query(findModuleById) 
    if (!moduleUser.rows.length>0) {
      return res.status(404).json({ error: [{ msg: "Module not exist" }] });
    }
    const user = await pool.query(updatemodule);
    const updatedetails = user.rows[0];
    res.status(200).json({
      data: [updatedetails],
      message: "module updated successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "module updation failed" });
  }
};

//delete module
module.exports.deleteModule = async function (req, res) {
  const pid = req.params.module_id;
  const deletemodule = `delete from module where module_id ='${pid}'`;
  try {
    const findModuleById = `select * from module where module_id='${pid}'`;
    let user = await pool.query(findModuleById);
    if (!user.rows.length > 0) {
      return res.status(404).json({ errors: [{ msg: "Module not found" }] });
    }
    await pool.query(deletemodule);
    res.status(200).json({
      data: [{ deleted_id: req.params.module_id }],
      message: "module deleted successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "module deletion failed" });
  }
};
