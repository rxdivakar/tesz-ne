// const userPool = require("../congnito");
// const AmazonCognitoIdentity = require("amazon-cognito-identity-js");
const pool = require("../../database");
const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");

// create tenant admin table
module.exports.createTenantAdminTable = async function (req, res) {
  // TODO: tenant_id is reference from tenant table - (done)

  const createTenantAdminTableQuery = `create table tenantadmin (
    tenant_id VARCHAR(100) NOT NULL,
    tenantAdmin_id VARCHAR(100) NOT NULL UNIQUE,
    tenantAdmin_fullname VARCHAR(250) NOT NULL,
    tenantAdmin_displayname VARCHAR(250) NOT NULL,
    tenantAdmin_designation VARCHAR(250) NOT NULL,
    tenantAdmin_email VARCHAR(250) NOT NULL UNIQUE,
    tenantAdmin_password VARCHAR(250) NOT NULL,
    tenantAdmin_country VARCHAR(250) NOT NULL,
    tenantAdmin_phone VARCHAR(250) NOT NULL,
    is_active BOOLEAN,
    CONSTRAINT tenant_ref FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id)
    )`;

  try {
    await pool.query(createTenantAdminTableQuery);
    res.send("TenantAdmin table created successfully");
  } catch (error) {
    console.log(error, "something went wrong,please try again later");
  }
};

//tenant admin entries

module.exports.createTenantAdmin = async function (req, res) {
  const {
    tenant_id ,
    tenantAdmin_fullname,
    tenantAdmin_displayname,
    tenantAdmin_designation,
    tenantAdmin_email,
    tenantAdmin_password,
    tenantAdmin_country,
    tenantAdmin_phone,
    is_active
  } = req.body;

  //TODO: tenantAdmin_password needs to be encrypted and stored in database and should not return in response

  let tenantAdmin_id = uuidv4();
  const findadminByEmail = `select * from tenantadmin where tenantAdmin_email ='${tenantAdmin_email}'`;

    try {
      let user = await pool.query(findadminByEmail);
      console.log(user.rows.length, user.rows.length > 0);
  
      if (user.rows.length > 0) {
        return res.status(400).json({ error: [{ msg: "user already present" }] });
      }
    //Check password criteria     

    const checkPassword = (value) => {
      const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+={}[\]\\|:;'<>,.?/])[a-zA-Z\d!@#$%^&*()_\-+={}[\]\\|:;'<>,.?/]{8,}$/;
      return regex.test(value);
    }
    let isPasswordValid = checkPassword(tenantAdmin_password)

    if (!isPasswordValid) {
      return res.status(400).json({ error: [{ msg: "Password doesn't match the requirement" }] });
    }
    //encrypt the password

    const salt = await bcrypt.genSalt(10);

    const hashedPassword = await bcrypt.hash(tenantAdmin_password, salt);

   const { rows } = await pool.query(`insert into tenantAdmin values(
    '${tenant_id}',
    '${tenantAdmin_id}',
    '${tenantAdmin_fullname}', 
    '${tenantAdmin_displayname}', 
    '${tenantAdmin_designation}', 
    '${tenantAdmin_email}',
    '${hashedPassword}',
    '${tenantAdmin_country}',
    '${tenantAdmin_phone}',
    '${is_active}') RETURNING tenant_id ,tenantAdmin_id,tenantAdmin_fullname,tenantAdmin_displayname,tenantAdmin_designation,tenantAdmin_email,tenantAdmin_country,
    tenantAdmin_phone,is_active`);
   res.status(200).json({ data: [rows[0]], message: "tenantAdmin created successfully" });

    // (Question) ==> Needs to be clarified with arch team
    // 1. This route should or should not hit congnito while creation
    // 2. While creating resources we can send these details on script pipelines
 } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenantAdmin creation failed" });
  }
};

//get all tenantadmindetails

module.exports.getAllTenantAdmins = async function (req, res) {
  
  //TODO: should fetch respected tenant details along with the all tenants admin in json

  const findAllTenantAdmin = `select Json_build_object('tenant_id',t1.tenant_id,
  'tenant_fullname',t1.tenant_fullname,
  'tenant_displayname',t1.tenant_displayname,
  'tenant_email',t1.tenant_email,
  'tenant_country',t1.tenant_country,
  'tenant_phone',t1.tenant_phone) as tenant_id,
  t2.tenantAdmin_id,t2.tenantAdmin_fullname,t2.tenantAdmin_displayname,
t2.tenantAdmin_designation,t2.tenantAdmin_email,t2.tenantAdmin_country,t2.tenantAdmin_phone,t2.is_active  
from tenant t1 inner join tenantadmin t2 on t1.tenant_id = t2.tenant_id`;
  try {
    const { rows } = await pool.query(findAllTenantAdmin);
    res
      .status(200)
      .json({ data: rows, message: "All TenantAdmins fetched successfully" });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .json({ error: error, message: "Get all tenantAdmin failed" });
  }
};

//get tenantadmin by tenant_id

module.exports.getTenantAdminById = async function (req, res) {
   //TODO: should fetch respected tenant details along with the all tenants admin in json
  const tid = req.params.tenant_id;
  const findProByid =`select Json_build_object('tenant_id',t1.tenant_id,
  'tenant_fullname',t1.tenant_fullname,
  'tenant_displayname',t1.tenant_displayname,
  'tenant_email',t1.tenant_email,
  'tenant_country',t1.tenant_country,
  'tenant_phone',t1.tenant_phone) as tenant_id,
  t2.tenantAdmin_id,t2.tenantAdmin_fullname,t2.tenantAdmin_displayname,
t2.tenantAdmin_designation,t2.tenantAdmin_email,t2.tenantAdmin_country,t2.tenantAdmin_phone,t2.is_active  
from tenant t1 inner join tenantadmin t2 on t1.tenant_id = t2.tenant_id where t2.tenant_id='${tid}'`;
    try {
    const user= await pool.query(findProByid)
if (!user.rows.length > 0) {
  return res.status(403).json({error:[{masg:"user not exist"}] });
}
const tenAdminDetails = user.rows[0]
    res
      .status(200)
      .json({ data: [tenAdminDetails,tid], message: "TenantAdmin fetched successfully" });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .json({ error: error, message: "tenantAdmin creation failed" });
  }
};

//update tenantadmin details 
module.exports.updateTenantadmin = async function (req, res) {
const aid =req.params.tenantAdmin_id;
const{tenantAdmin_fullname,
  tenantAdmin_displayname,
  tenantAdmin_designation,
  tenantAdmin_email,
  tenantAdmin_password,
  tenantAdmin_country,
  tenantAdmin_phone,
  is_active}=req.body;

const updateTenantAdmin = `update tenantadmin set 
tenantAdmin_fullname ='${tenantAdmin_fullname}',
tenantAdmin_displayname ='${tenantAdmin_displayname}',
tenantAdmin_designation ='${tenantAdmin_designation}',
tenantAdmin_email ='${tenantAdmin_email}',
tenantAdmin_password ='${tenantAdmin_password}',
tenantAdmin_country ='${tenantAdmin_country}',
tenantAdmin_phone ='${tenantAdmin_phone}',
is_active ='${is_active}' where tenantAdmin_id ='${aid}' RETURNING *`;

try {
  const user= await pool.query(updateTenantAdmin);
  if (!user.rows.length > 0) {
    return res.status(404).json({ error: [{ msg: "user not exist" }] });
  } 
const updateDetails=user.rows[0]

res.status(200).json({
  data: [req.body,req.params.tenantAdmin_id,updateDetails],
  message: "tenant updated successfully"
});
} catch (error) {
console.log(error);
res.status(500).json({ error: error, message: "tenant updation failed" });
}
};


//delete admin details
module.exports.deleteTenantadmin = async function (req, res) {
  const aid =req.params.tenantAdmin_id;
  const deleteTenant = `delete from tenantadmin where tenantAdmin_id ='${aid}'`;

  try {
    const findProductById = `select * from tenantadmin where tenantAdmin_id ='${aid}'`;
    let user = await pool.query(findProductById);
    if (!user.rows.length > 0) {
      return res.status(404).json({ errors: [{ msg: "User not found" }] });
    }
    await pool.query(deleteTenant);

    res.status(200).json({data: [{deleted_id:req.params.tenantAdmin_id}],message: "product deleted successfully"});
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenant deletion failed" });
  }
};