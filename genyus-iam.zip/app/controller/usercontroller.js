const pool = require("../../database");
const userPool = require("../congnito");
const AmazonCognitoIdentity = require("amazon-cognito-identity-js");

module.exports.createUser = async function (req, res) {
  const { email, password } = req.body;
  const attributeList = [];
  attributeList.push(
    new AmazonCognitoIdentity.CognitoUserAttribute({
      Name: "email",
      Value: email
    })
  );
  // The username can be a UUID or any other unique string
  const username = email;
  userPool.signUp(username, password, attributeList, null, (err, result) => {
    if (err) {
      res.status(400).send(err.message || JSON.stringify(err));
      return;
    }
    const cognitoUser = result.user;
    res.send(`User ${cognitoUser.getUsername()} is created`);
  });
};

module.exports.loginUser = async function (req, res) {
  const { email, password } = req.body;
  const authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(
    {
      Username: email,
      Password: password
    }
  );
  const cognitoUser = new AmazonCognitoIdentity.CognitoUser({
    Username: email, // Here email is used as an alias
    Pool: userPool
  });
  cognitoUser.authenticateUser(authenticationDetails, {
    onSuccess: (result) => {
      const accessToken = result.getAccessToken().getJwtToken();
      const refreshToken = result.getRefreshToken().getToken();
      const id = result.accessToken.payload.username
     
      res.send([
        {
          accessToken,
          refreshToken,
          id,
        }
      ]);
    },
    onFailure: (err) => {
      res.status(400).send([{ err }, err.message || JSON.stringify(err)]);
    }
  });
};

module.exports.verifyUser = async function (req, res) {
  const { email, code } = req.body;
  const userData = {
    Username: email,
    Pool: userPool
  };
  const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
  cognitoUser.confirmRegistration(code, true, (err, result) => {
    if (err) {
      res.status(400).send([{ err }, JSON.stringify(err.message)]);
      return;
    }
    res.send("Account verified successfully.");
  });
};

module.exports.resendVerificationUser = async function (req, res) {
  const { email } = req.body;
  const userData = {
    Username: email,
    Pool: userPool
  };
  const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
  cognitoUser.resendConfirmationCode((err, result) => {
    if (err) {
      res.status(400).send(err.message || JSON.stringify(err));
      return;
    }
    res.send([{ result }, "Verification code resent successfully."]);
  });
};

// module.exports.getallUsers = async function (req, res) {
//   const { email } = req.body;
//   const userData = {
//     Username: email,
//     Pool: userPool
//   };
//   const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
//   cognitoUser.resendConfirmationCode((err, result) => {
//     if (err) {
//       res.status(400).send(err.message || JSON.stringify(err));
//       return;
//     }
//     res.send([{ result }, "Verification code resent successfully."]);
//   });
// };

// app.get('/listUsers', (req, res) => {
//   const params = {
//       UserPoolId: 'YOUR_COGNITO_USER_POOL_ID',
//       Limit: 10 // You can adjust this limit
//   };

//   cognitoidentityserviceprovider.listUsers(params, function(err, data) {
//       if (err) {
//           console.log(err, err.stack); // an error occurred
//           res.status(500).send(err);
//       } else {
//           console.log(data);           // successful response
//           res.json(data);
//       }
//   });
// });

//create tables
module.exports.createTables = async function (req, res) {
  const createProductTableQuery = `create table product (
    product_id VARCHAR(100000) NOT NULL UNIQUE,
    product_name VARCHAR(10000) NOT NULL UNIQUE,
    product_desc VARCHAR(10000),
    product_price VARCHAR(10000) NOT NULL,
    is_active BOOLEAN,
    CONSTRAINT productref PRIMARY KEY (product_id)
    )`;
  const createModuleTableQuery = `create table module (
      product_id VARCHAR(150) NOT NULL,
      module_id VARCHAR(100000) NOT NULL UNIQUE,
      module_name VARCHAR(10000) NOT NULL UNIQUE,
      module_desc VARCHAR(10000),
      module_price VARCHAR(10000) NOT NULL,
      is_active BOOLEAN,
      module_permissions json NOT NULL,
      CONSTRAINT product_ref FOREIGN KEY (product_id) REFERENCES product(product_id)
      )`;
  const createTenantTableQuery = `create table tenant (
        tenant_id VARCHAR(100) NOT NULL UNIQUE ,
        tenant_fullname VARCHAR(250) NOT NULL,
        tenant_displayname VARCHAR(250) NOT NULL,
        tenant_email VARCHAR(250) NOT NULL UNIQUE,
        tenant_country VARCHAR(250) NOT NULL,
        tenant_phone VARCHAR(250) NOT NULL,
        is_active BOOLEAN,
        CONSTRAINT tenantadminref PRIMARY KEY (tenant_id)
        )`;
  const createTenantAdminTableQuery = `create table tenantadmin (
          tenant_id VARCHAR(100) NOT NULL,
          tenantAdmin_id VARCHAR(100) NOT NULL UNIQUE,
          tenantAdmin_fullname VARCHAR(250) NOT NULL,
          tenantAdmin_displayname VARCHAR(250) NOT NULL,
          tenantAdmin_designation VARCHAR(250) NOT NULL,
          tenantAdmin_email VARCHAR(250) NOT NULL UNIQUE,
          tenantAdmin_password VARCHAR(250) NOT NULL,
          tenantAdmin_country VARCHAR(250) NOT NULL,
          tenantAdmin_phone VARCHAR(250) NOT NULL,
          is_active BOOLEAN,
          CONSTRAINT tenant_ref FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id)
          )`;
  const createSubscriptionTableQuery = `CREATE TABLE subscription (
        subscription_id VARCHAR(10000) NOT NULL UNIQUE,
        subscription_name VARCHAR(10000) NOT NULL UNIQUE,
        products uuid[] NOT NULL ,
        modules uuid[] NOT NULL ,
        is_active BOOLEAN,
        subscription_type VARCHAR(10000) NOT NULL
    )`;
    const createSubTenantTable = `create table Subtenant (
      subscription_tenant_id VARCHAR(100) NOT NULL UNIQUE ,
      subscription_id VARCHAR(250) NOT NULL,
      tenant_id VARCHAR(250) NOT NULL,
      is_active BOOLEAN ,
      start_date VARCHAR(250) NOT NULL,
      end_date VARCHAR(250) NOT NULL,
      payment_id VARCHAR(250) NOT NULL UNIQUE
      )`;
  try {
    await pool.query(createProductTableQuery);
    await pool.query(createModuleTableQuery);
    await pool.query(createTenantTableQuery);
    await pool.query(createTenantAdminTableQuery);
    await pool.query(createSubscriptionTableQuery);
    await pool.query(createSubTenantTable);
    res.send("Product table created successfully");
  } catch (error) {
    console.log(error, "something went wrong,please try again later");
  }
};
