const userPool = require("../congnito");
const AmazonCognitoIdentity = require("amazon-cognito-identity-js");
const pool = require("../../database");

module.exports.createPermissionTable = async function (req, res) {
  const createPermissionTableQuery = `create table product_permission (
    permission_id VARCHAR(100000) NOT NULL UNIQUE,
    permission_name VARCHAR(10000) NOT NULL,
    permission_desc VARCHAR(10000),
    permission_price VARCHAR(10000) NOT NULL,
    is_active boolean
    )`;

  try {
    await pool.query(createPermissionTableQuery);
    res.send("Permission table created successfully");
  } catch (error) {
    console.log(error, "something went wrong,please try again later");
  }
};

module.exports.createPermission = async function (req, res) {
  const { permission_id, permission_name, permission_desc, permission_price, is_active } =
    req.body;

  try {
    const data = await pool.query(`insert into permission values(
    '${permission_id}',
    '${permission_name}', 
    '${permission_desc}', 
    '${permission_price}',
    '${is_active}')`);

    console.log(data);

    res.status(200).json({ data: [], message: "permission created successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "permission creation failed" });
  }
};

module.exports.getAllPermissions = async function (req, res) {
  try {
    // const data = await pool.query(`insert into permission values(
    // '${permission_id}',
    // '${permission_name}',
    // '${permission_desc}',
    // '${permission_price}',
    // '${is_active}')`);

    // console.log(data);

    res
      .status(200)
      .json({ data: [], message: "All Permissions fetched successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "permission creation failed" });
  }
};

module.exports.getPermissionById = async function (req, res) {
  try {
    // const data = await pool.query(`insert into permission values(
    // '${permission_id}',
    // '${permission_name}',
    // '${permission_desc}',
    // '${permission_price}',
    // '${is_active}')`);

    // console.log(data);

    res
      .status(200)
      .json({ data: [], message: "Permission fetched successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "permission creation failed" });
  }
};

module.exports.updatePermission = async function (req, res) {
  console.log(req.body, req.params.permission_id);

  try {
    // const data = await pool.query(`insert into permission values(
    // '${permission_id}',
    // '${permission_name}',
    // '${permission_desc}',
    // '${permission_price}',
    // '${is_active}')`);
    // console.log(data);

    res.status(200).json({
      data: [req.body, req.params.permission_id],
      message: "permission updated successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "permission updation failed" });
  }
};

module.exports.deletePermission = async function (req, res) {
  console.log(req.body, req.params.permission_id);

  try {
    // const data = await pool.query(`insert into permission values(
    // '${permission_id}',
    // '${permission_name}',
    // '${permission_desc}',
    // '${permission_price}',
    // '${is_active}')`);
    // console.log(data);

    res.status(200).json({
      data: [req.params.permission_id],
      message: "permission deleted successfully"
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "permission updation failed" });
  }
};
