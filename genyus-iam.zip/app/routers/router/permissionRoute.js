var express = require("express");
var router = express.Router();
// const { check, validationResult } = require("express-validator");
const permissionController = require("../../controller/permissionController");


// post sample route for permission table creation
router.post("/create-permission-table", permissionController.createPermissionTable);

//post method
//this route for permission create
//http://localhost:4000/api/permission/create
router.post("/create", permissionController.createPermission);

//get method
//this route for get permission by ID
//http://localhost:4000/api/permission/getpermission/123
router.post("/get/:permission_id", permissionController.getPermissionById);

//get method
//this route for get all permissions
//http://localhost:4000/api/permission/getallpermissions
router.post("/getall", permissionController.getAllPermissions);

//put method
//this route for permission update
//http://localhost:4000/api/permission/update/123
router.put("/update/:permission_id", permissionController.updatePermission);

//delete method
//this route for permission deletion
//http://localhost:4000/api/permission/delete/123
router.delete("/delete/:permission_id", permissionController.deletePermission);

module.exports = router;
