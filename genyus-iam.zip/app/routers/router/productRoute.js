var express = require("express");
var router = express.Router();
const { check, validationResult } = require("express-validator");
const productController = require("../../controller/productController");

//post method
//this route for product create
//http://localhost:4000/api/product/create
router.post("/create", productController.productEntry);

//get method
//this route for get all products
//http://localhost:4000/api/product/getall
router.get("/getall", productController.getAllProducts);

//get method
//this route for get product by ID
//http://localhost:4000/api/product/get
router.get("/get/:product_id", productController.getProductById);

//get method
//this route for get tenant details product by ID
//http://localhost:4000/api/product/get-tenant
router.get("/get-tenant/:product_id", productController.getTenantProductById);

//put method
//this route for product update
//http://localhost:4000/api/product/update/123
router.put("/update/:product_id", productController.updateProduct);

//delete method
//this route for product deletion
//http://localhost:4000/api/product/delete/123
router.delete("/delete/:product_id", productController.deleteProduct);

module.exports = router;
