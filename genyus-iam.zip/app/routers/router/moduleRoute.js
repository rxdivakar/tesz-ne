var express = require("express");
var router = express.Router();
const { check, validationResult } = require("express-validator");
const moduleController = require("../../controller/moduleController");


// post sample route for module table creation
router.post("/create-table", moduleController.createModuleTable);

//post method
//this route for module create
//http://localhost:4000/api/module/create
router.post("/create", moduleController.moduleEntry);

//get method
//this route for get all modules
//http://localhost:4000/api/module/getall
router.get("/getall", moduleController.getAllModules);

// //get method
// //this route for get module by ID
// //http://localhost:4000/api/module/getbyid/123
router.get("/getbyid/:module_id", moduleController.getModuleById);

// //put method
// //this route for module update
// //http://localhost:4000/api/module/update/123
router.put("/update/:module_id", moduleController.updateModule);

// //delete method
// //this route for module deletion
// //http://localhost:4000/api/module/delete/123
router.delete("/delete/:module_id", moduleController.deleteModule);

module.exports = router;
