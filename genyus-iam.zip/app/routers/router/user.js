var express = require("express");
var router = express.Router();
const { check, validationResult } = require("express-validator");
var userController = require("../../controller/usercontroller");

//post method
//this fn user for register user
//http://localhost:4000/api/user/create-tables
router.post("/create-tables", userController.createTables);

//post method
//this fn user for register user
//http://localhost:4000/api/user/create
router.post("/create", userController.createUser);

//post method
//this fn user for login user
//http://localhost:4000/api/user/create
router.post("/login", userController.loginUser);


//post method
//this fn user for verify
//http://localhost:4000/api/user/verify
router.post("/verify", userController.verifyUser);

//post method
//this fn user for resend verification code
//http://localhost:4000/api/user/resendVerification
router.post("/resendVerification", userController.resendVerificationUser);

module.exports = router;