var express = require("express");
var router = express.Router();
const { check, validationResult } = require("express-validator");
const tenantController = require("../../controller/tenantController");


// post sample route for tenant table creation
router.post("/create-tenant-table", tenantController.createTenantTable);

//post method
//this route for tenant create
//http://localhost:4000/api/tenant/create
router.post("/create", tenantController.tenantEntry);

// //get method
// //this route for get tenant by ID
// //http://localhost:4000/api/tenant/gettenant/123
router.get("/get/:tenant_id", tenantController.getTenantById);

// //get method -- getAllSubscriptionBytenantID
// //this route for get tenant by ID
// //http://localhost:4000/api/tenant/gettenant/123
router.get("/getsub-tenants", tenantController.getAllSubscriptionBytenants);

//get method
//this route for get all tenants
//http://localhost:4000/api/tenant/getalltenants
router.get("/getall", tenantController.getAllTenants);

// //put method
// //this route for tenant update
// //http://localhost:4000/api/tenant/update/123
router.put("/update/:tenant_id", tenantController.updateTenant);

// //delete method
// //this route for tenant deletion
// //http://localhost:4000/api/tenant/delete/123
router.delete("/delete/:tenant_id", tenantController.deleteTenant);

module.exports = router;
