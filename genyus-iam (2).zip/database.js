const { Pool, Client } = require("pg");

const client = new Client({
  host: process.env.RDS_HOSTNAME,
  port: process.env.RDS_PORT,
  database: process.env.RDS_DB_NAME,
  user: process.env.RDS_USERNAME,
  password: process.env.RDS_PASSWORD,
  dialect: "postgres",
  dialectOptions: {
    ssl: { require: true }
  }
});

const pool = new Pool({
  user: process.env.RDS_USERNAME,
  password: process.env.RDS_PASSWORD,
  host: process.env.RDS_HOSTNAME,
  port: process.env.RDS_PORT,
  database: process.env.RDS_DB_NAME,
  ssl: true,
  dialect: "postgres",
  dialectOptions: {
    ssl: { require: true }
  }
});

module.exports = { pool, client };
