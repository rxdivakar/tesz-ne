let express = require("express");
let api = express.Router();

let userRoutes = require('./router/user');
let authRoutes = require('./router/auth');
let productRoutes = require('./router/productRoute');
let permissionRoutes = require('./router/permissionRoute');
let tenantRoutes = require('./router/tenantRoute');
let tenantAdminRoutes = require('./router/tenantAdminRoute');
let moduleRoutes = require('./router/moduleRoute');
let subscriptionRoutes = require('./router/subscription');
let subscriptionTenantRoutes = require('./router/subscriptiontenant');

api.use("/user", userRoutes);
api.use("/auth", authRoutes);
api.use("/product", productRoutes);
api.use("/permission", permissionRoutes);
api.use("/tenant", tenantRoutes);
api.use("/tenant-admin", tenantAdminRoutes);
api.use("/module", moduleRoutes);
api.use("/subscription",subscriptionRoutes);
api.use("/subscriptiontenant",subscriptionTenantRoutes);
module.exports = api;