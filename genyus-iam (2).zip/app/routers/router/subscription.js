var express = require("express");
var router = express.Router();
const { check, validationResult } = require("express-validator");
const subscriptionController = require('../../controller/subscriptionController.js');

// post sample route for subscription table creation
// http://localhost:4000/api/subscription/create-subscription-table
router.post("/create-subscription-table",subscriptionController.createSubscriptionTable);

//post method
//this route for subscription entry
//http://localhost:4000/api/subscription/create
router.post("/create",subscriptionController.subscriptionEntry);

//get method
//this route for get all subscription details
//http://localhost:4000/api/subscription/getall
router.get("/getall",subscriptionController.getAllSubscription);

//get method
//this route for get subscription by Id
//http://localhost:4000/api/subscription/get/123
router.get("/get/:subscription_id",subscriptionController.getSubscriptionById);

//put method
//this route for update subscription by Id
//http://localhost:4000/api/subscription/update/123
router.put("/update/:subscription_id",subscriptionController.updateSubscriptionById);

//delete method
//this route for delete subscription by Id
//http://localhost:4000/api/subscription/delete/123
router.delete("/delete/:subscription_id",subscriptionController.deleteSubscriptionById);

module.exports = router;