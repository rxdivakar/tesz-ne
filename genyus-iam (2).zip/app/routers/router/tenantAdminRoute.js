var express = require("express");
var router = express.Router();
const { check, validationResult } = require("express-validator");
const tenantAdminController = require("../../controller/tenantAdminController");


// post sample route for tenant table creation
router.post("/create-table", tenantAdminController.createTenantAdminTable);

//post method
//this route for tenant create
//http://localhost:4000/api/tenant-admin/adminentry
router.post("/create", tenantAdminController.createTenantAdmin);

//get method
//this route for get all tenants
//http://localhost:4000/api/tenant-admin/getall
router.get("/getall", tenantAdminController.getAllTenantAdmins);

//get method
//this route for get tenant by ID
//http://localhost:4000/api/tenant-admin/getbyid/123
router.get("/get/:tenant_id", tenantAdminController.getTenantAdminById);

//put method
//this route for tenant update
//http://localhost:4000/api/tenant-admin/update/123
router.put("/update/:tenantAdmin_id", tenantAdminController.updateTenantadmin);

// //delete method
// //this route for tenant deletion
// //http://localhost:4000/api/tenant-admin/delete/123
router.delete("/delete/:tenantAdmin_id", tenantAdminController.deleteTenantadmin);

module.exports = router;
