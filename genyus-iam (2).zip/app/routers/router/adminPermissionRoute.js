var express = require("express");
var router = express.Router();
// const { check, validationResult } = require("express-validator");
const adminPermissionController = require("../../controller/admin-permissionController");


// post sample route for admin-permission table creation
router.post("/create-admin-permission-table", adminPermissionController.createAdminPermissionTable);

//post method
//this route for admin-permission create
//http://localhost:4000/api/admin-permission/create
router.post("/create", adminPermissionController.createAdminPermission);

//get method
//this route for get admin-permission by ID
//http://localhost:4000/api/admin-permission/getadmin-permission/123
router.post("/getadmin-permission/:admin-permission_id", adminPermissionController.getAdminPermission);

//get method
//this route for get all admin-permissions
//http://localhost:4000/api/admin-permission/getalladmin-permissions
router.post("/getalladmin-permissions", adminPermissionController.getAllAdminPermission);

//put method
//this route for admin-permission update
//http://localhost:4000/api/admin-permission/update/123
router.put("/update/:admin-permission_id", adminPermissionController.updateAdminPermission);

//delete method
//this route for admin-permission deletion
//http://localhost:4000/api/admin-permission/delete/123
router.delete("/delete/:admin-permission_id", adminPermissionController.deleteAdminPermission);

module.exports = router;
