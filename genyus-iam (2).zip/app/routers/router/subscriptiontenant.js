var express = require("express");
var router = express.Router();
const { check, validationResult } = require("express-validator");
const subscriptiontenantController = require('../../controller/subscriptiontenantController');

//post method
//this route for subscription entry
//http://localhost:4000/api/subscriptiontenant/create-subtenant
router.post("/create-subtenant",subscriptiontenantController.createSubTenantTable);

//post method
//this route for subscription entry
//http://localhost:4000/api/subscriptiontenant/create
router.post("/create",subscriptiontenantController.subTenantEntry);

//get method
//this route for subscription entry
//http://localhost:4000/api/subscriptiontenant/getall
router.get("/getall",subscriptiontenantController.getAllSubtenant);


//get method
//this route for subscription entry
//http://localhost:4000/api/subscriptiontenant/getbyid/id
router.get("/get/:subscription_tenant_id",subscriptiontenantController.getSubtenantById);

//put method
//this route for subscription entry
//http://localhost:4000/api/subscriptiontenant/update/id
router.put("/update/:subscription_tenant_id",subscriptiontenantController.updateSubtenantById);

//put method
//this route for subscription entry
//http://localhost:4000/api/subscriptiontenant/delete/id
router.delete("/delete/:subscription_tenant_id",subscriptiontenantController.deleteSubtenant);

module.exports = router;