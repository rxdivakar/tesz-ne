const pool = require('../../database');
const { v4: uuidv4 } = require("uuid");


//subscription table create
module.exports.createSubscriptionTable = async function (req, res) {
    const createSubscriptionTableQuery = `CREATE TABLE subscription (
        subscription_id VARCHAR(10000) NOT NULL UNIQUE,
        subscription_name VARCHAR(10000) NOT NULL UNIQUE,
        products uuid[] NOT NULL ,
        modules uuid[] NOT NULL ,
        is_active BOOLEAN,
        subscription_type VARCHAR(10000) NOT NULL
    )`;
    try {
        await pool.query(createSubscriptionTableQuery);
        res.send("Subscription table created successfully");
    } catch (error) {
        console.log(error, "something went wrong,please try again later");
    }
}

//subscription entry
module.exports.subscriptionEntry = async function (req, res) {
    let {
        subscription_name,
        products,
        modules,
        is_active,
        subscription_type
    } = req.body;
    const findSubId = `select * from subscription where subscription_name = '${subscription_name}'`;
    try {
        let user = await pool.query(findSubId);
        if (user.rows.length > 0) {
            return res.status(403).json({ error: [{ msg: "subscription already present" }] });
        }
        let subscription_id = uuidv4();
        let insertData = (`INSERT INTO subscription (subscription_id,subscription_name, products, modules, is_active, subscription_type)
        VALUES (
            '${subscription_id}',
            '${subscription_name}',
            ARRAY[${products.map(item => `'${item}'`).join(', ')}]::uuid[],
            ARRAY[${modules.map(item => `'${item}'`).join(', ')}]::uuid[],
            '${is_active}',
            '${subscription_type}') RETURNING *`);
        const respone = await pool.query(insertData);
        res.status(200).json({
            data: [respone.rows[0]],
            message: "subscription created successfully"
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: error, message: "subscription creation failed" });
    }
}

//get all subscription
module.exports.getAllSubscription = async function (req, res) {

            const allSubscription = `SELECT
                            s.subscription_id,
                            s.subscription_name,
                            s.products,
                            s.modules,
                            s.subscription_type,
                            CASE
                                WHEN ARRAY_LENGTH(s.products, 1) IS NOT NULL AND ARRAY_LENGTH(s.modules, 1) IS NOT NULL THEN
                                    COALESCE(jsonb_agg(DISTINCT
                                        jsonb_build_object(
                                            'product_id', COALESCE(p.product_id, ''),
                                            'product_name', COALESCE(p.product_name, ''),
                                            'product_desc', COALESCE(p.product_desc, ''),
                                            'product_price', COALESCE(p.product_price, ''),
                                            'is_active', COALESCE(p.is_active, false)
                                        )
                                    ), '[]'::jsonb)
                                ELSE '[]'::jsonb
                            END AS products_data,
                            CASE
                                WHEN ARRAY_LENGTH(s.products, 1) IS NOT NULL AND ARRAY_LENGTH(s.modules, 1) IS NOT NULL THEN
                                    COALESCE(jsonb_agg(DISTINCT
                                        jsonb_build_object(
                                            'module_id', COALESCE(m.module_id, ''),
                                            'module_name', COALESCE(m.module_name, ''),
                                            'module_desc', COALESCE(m.module_desc, ''),
                                            'module_price', COALESCE(m.module_price, ''),
                                            'is_active', COALESCE(m.is_active, false)
                                        )
                                    ), '[]'::jsonb)
                                ELSE '[]'::jsonb
                            END AS modules_data
                            FROM
                            subscription s
                            LEFT JOIN product p ON p.product_id = ANY(CAST((s.products::uuid[]) AS VARCHAR[]))
                            LEFT JOIN module m ON m.module_id = ANY(CAST((s.modules::uuid[]) AS VARCHAR[]))
                            GROUP BY 
                            s.subscription_id,
                            s.subscription_name,
                            s.products,
                            s.modules,
                            s.subscription_type;`
    try {
        const data = await pool.query(allSubscription);
        const subcriptionData = data.rows;
        return res.status(200).json({
            data: subcriptionData,
            message: "All subscription details fetched successfully"
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: error, message: "Your request get failed" });
    }
}

//get subscription by subscriptionId
module.exports.getSubscriptionById = async function (req, res) {
    const sid = req.params.subscription_id;
    const findSubByid = `SELECT
    s.subscription_id,
    s.subscription_name,
    s.products,
    s.modules,
    s.subscription_type,
    jsonb_agg(
        jsonb_build_object(
            'product_id', p.product_id,
            'product_name', p.product_name,
            'product_desc', p.product_desc,
            'product_price', p.product_price,
            'is_active', p.is_active
        )
    ) AS products_data,
    jsonb_agg( DISTINCT
        jsonb_build_object(
            'module_id', m.module_id,
            'module_name', m.module_name,
            'module_desc', m.module_desc,
            'module_price', m.module_price,
            'is_active', m.is_active
        )
    ) AS modules_data
FROM
    subscription s
    LEFT JOIN product p ON p.product_id = ANY(CAST((s.products::uuid[]) AS VARCHAR[]))
    LEFT JOIN module m ON m.module_id = ANY(CAST((s.modules::uuid[]) AS VARCHAR[]))
WHERE
    s.subscription_id = '${sid}'::VARCHAR
    GROUP BY 
    s.subscription_id,
    s.subscription_name,
    s.products,
    s.modules,
    s.subscription_type;
`;


    try {
        const user = await pool.query(findSubByid);
        if (!user.rows.length > 0) {
            return res.status(404).json({ error: [{ msg: "subscription not exist" }] });
        }
        const subDetails = user.rows[0]
        res.status(200).json({ data: [subDetails], message: "subscription fetched successfully" });
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            error: error,
            message: "Your request get failed"
        })
    }
}

//update subscription
module.exports.updateSubscriptionById = async function (req, res) {
    const sid = req.params.subscription_id;
    const findsubById = `select * from subscription where subscription_id='${sid}'`;
    let { subscription_name, products, modules, subscription_type, is_active } = req.body;

    const updateSubscription = `UPDATE subscription
    SET
        subscription_name = '${subscription_name}',
        products = ARRAY[${products.map(item => `'${item}'`).join(', ')}]::uuid[],
        modules = ARRAY[${modules.map(item => `'${item}'`).join(', ')}]::uuid[],
        is_active = '${is_active}',
        subscription_type = '${subscription_type}'
        WHERE
            subscription_id = '${sid}'
        RETURNING *`;

    try {
        const findSubs = await pool.query(findsubById)
        if (!findSubs.rows.length > 0) {
            return res.status(404).json({ error: [{ msg: "user not exist" }] });
        }
        const updates = await pool.query(updateSubscription);
        const updatedetails = updates.rows[0];
        res.status(200).json({ data: [updatedetails], message: "subcription updated successfully" });

    } catch (error) {
        console.log(error)
        return res.status(500).json({
            error: error,
            message: "subscription updated successfully"
        })
    }
}

//delete subscription
module.exports.deleteSubscriptionById = async function (req, res) {
    const sid = req.params.subscription_id;
    const deleteSubscription = `delete from subscription where subscription_id ='${sid}'`;
    try {
        const findSubsById = `select * from subscription where subscription_id='${sid}'`;
        let user = await pool.query(findSubsById);
        if (!user.rows.length > 0) {
            return res.status(404).json({ errors: [{ msg: "subscription not found" }] })
        }
        await pool.query(deleteSubscription);
        res.status(200).json({ data: [{ deleted_id: req.params.subscription_id }], message: "subscription deleted successfully" });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: error, message: "subscription deletion failed" });
    }

}