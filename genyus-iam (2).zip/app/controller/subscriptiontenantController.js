const pool = require("../../database");
const { v4: uuidv4 } = require("uuid");

//create subscription tenant table 

module.exports.createSubTenantTable = async function (req, res) {
    const createSubTenantTable = `create table Subtenant (
      subscription_tenant_id VARCHAR(100) NOT NULL UNIQUE ,
      subscription_id VARCHAR(250) NOT NULL,
      tenant_id VARCHAR(250) NOT NULL,
      is_active BOOLEAN ,
      start_date VARCHAR(250) NOT NULL,
      end_date VARCHAR(250) NOT NULL,
      payment_id VARCHAR(250) NOT NULL UNIQUE
      )`;
  
    try {
      await pool.query(createSubTenantTable);
      res.send("Subtenant table created successfully");
    } catch (error) {
      console.log(error, "something went wrong,please try again later");
    }
  };

  //enter suntenant values
  module.exports.subTenantEntry = async function (req, res) {

    const {
      subscription_id,
      tenant_id,
      is_active,
      start_date,
      end_date,
      payment_id,
     } = req.body;
  
    let subscription_tenant_id = uuidv4();
  
    const findTenantByEmail = `select * from  Subtenant where subscription_id = '${subscription_id}'`;
    try {
      let user = await pool.query(findTenantByEmail);
  
      if (user.rows.length > 0) {
        return res.status(403).json({ error: [{ msg: "user already present" }] });
      }
      const { rows } = await pool.query(`insert into Subtenant values(
      '${subscription_tenant_id}',
      '${subscription_id}',
      '${tenant_id}', 
      '${is_active}', 
      '${start_date}',
      '${end_date}',
      '${payment_id}') RETURNING *`);
  
      res
        .status(200)
        .json({ data: [rows[0]], message: "subtenant created successfully" });
    } catch (error) {
      console.log(error);
      res.status(500).json({ error: error, message: "subtenant creation failed" });
    }
  };
  

//get all subscription tenant details 

  module.exports.getAllSubtenant = async function (req, res) {
    const findAllSubTenant = `select t1.subscription_tenant_id,
    Json_build_object('subscription_id',t2.subscription_id,
      'subscription_name',t2.subscription_name,
      'products',t2.products,
      'modules',t2.modules,
      'is_active',t2.is_active,
      'subscription_type',t2.subscription_type) as subscription_id,
    Json_build_object('tenant_id',t3.tenant_id,
               'tenant_fullname',t3.tenant_fullname,
               'tenant_displayname',t3.tenant_displayname,
                'tenant_email',t3.tenant_email,
                'tenant_country',t3.tenant_country,
				 'tenant_phone',t3.tenant_phone,
				'is_active',t3.is_active) as tenant_id,
	t1.is_active,t1.start_date,t1.end_date,t1.payment_id			
    from Subtenant t1
    inner join subscription t2 on t2.subscription_id =t1.subscription_id
    inner join  tenant t3 on t3.tenant_id = t1.tenant_id`;

    try {
      const { rows } = await pool.query(findAllSubTenant);
      res
        .status(200)
        .json({ data: rows, message: "All Tenants fetched successfully" });
    } catch (error) {
      console.log(error);
      res.status(500).json({ error: error, message: "tenant creation failed" });
    }
  };

  
  //get all subscription tenant details by subcription id


  module.exports.getSubtenantById = async function (req, res) {
    const sid = req.params.subscription_tenant_id;
    const findTenantById = `select t1.subscription_tenant_id,
    Json_build_object('subscription_id',t2.subscription_id,
      'subscription_name',t2.subscription_name,
      'products',t2.products,
      'modules',t2.modules,
      'is_active',t2.is_active,
      'subscription_type',t2.subscription_type) as subscription_id,
    Json_build_object('tenant_id',t3.tenant_id,
               'tenant_fullname',t3.tenant_fullname,
               'tenant_displayname',t3.tenant_displayname,
                'tenant_email',t3.tenant_email,
                'tenant_country',t3.tenant_country,
				 'tenant_phone',t3.tenant_phone,
				'is_active',t3.is_active) as tenant_id,
	t1.is_active,t1.start_date,t1.end_date,t1.payment_id			
    from Subtenant t1
    inner join subscription t2 on t2.subscription_id =t1.subscription_id
    inner join  tenant t3 on t3.tenant_id = t1.tenant_id where t1.subscription_tenant_id='${sid}'`
    try {
      const tenantUser = await pool.query(findTenantById)
      if (!tenantUser.rows.length > 0) {
        return res.status(404).json({ error: [{ msg: "customer not exist" }] });
      }
      const tenantDetails = tenantUser.rows[0];
  
      res.status(200).json({ data: [tenantDetails], message: "customer fetched successfully" });
    } catch (error) {
      console.log(error);
      res.status(500).json({ error: error, message: "customer creation failed" });
    }
  };

  // update subscription tenant details

module.exports.updateSubtenantById = async function (req, res) {
  const sid = req.params.subscription_tenant_id;

  const { subscription_id,
    tenant_id,
    is_active,
    start_date ,
    end_date,
    payment_id } = req.body;

  const updatenant = `update Subtenant set subscription_id ='${subscription_id}',tenant_id ='${tenant_id}',is_active='${is_active}',
  start_date ='${start_date}',end_date='${end_date}',payment_id='${payment_id}' where subscription_tenant_id ='${sid}' RETURNING *`;

  const findSubTenant = `select * from Subtenant where subscription_tenant_id ='${sid}'`;
  try {
    const tenantUser = await pool.query(findSubTenant);

    if (!tenantUser.rows.length > 0) {
      return res.status(404).json({ error: [{ msg: "customer not exist" }] });
    }
    const updatedTenant = await pool.query(updatenant)

    const updatedList = updatedTenant.rows[0]
    res.status(200).json({
      data: [req.body, req.params.subscription_tenant_id, updatedList],
      message: "tenant updated successfully"
    });

  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenant updation failed" });
  }
};


//Delete subscription tenant details 

module.exports.deleteSubtenant = async function (req, res) {
  const sid = req.params.subscription_tenant_id;
  const findTenant = `select * from Subtenant where subscription_tenant_id ='${sid}'`;
  const deleteTenant = `delete from Subtenant where subscription_tenant_id ='${sid}'`;

  try {
    const tenantUser = await pool.query(findTenant);
    if (!tenantUser.rows.length > 0) {
      return res.status(404).json({ error: [{ msg: "customer not exist" }] });
    }
    await pool.query(deleteTenant);

    res.status(200).json({data: [{deleted_id:req.params.subscription_tenant_id}],message: "customer deleted successfully"});
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error, message: "tenant deletion failed" });
  }
};




