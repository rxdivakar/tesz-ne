## To run the app in local 
1. Refer .env.example 
2. Copy the content of .env.example to .env.local
3. .env will point to production api & .env.example will point to dev api


## Available Scripts

In the project directory, you can run:

### `yarn`
To install all the packages

### `yarn start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `yarn build`

Builds the app for production to the `build` folder.\
