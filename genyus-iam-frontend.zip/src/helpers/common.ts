// Format the phone number to american standard
export function formatPhoneNumber (value) {
  if (!value) return null
  const phoneNumber = value?.replace(/[^\d]/g, '')
  const phoneNumberLength = phoneNumber.length
  if (phoneNumberLength < 4) return phoneNumber
  if (phoneNumberLength < 7) {
    return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`
  }
  return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`
}
// Download the Excel fiele from base64 string
export function downloadExcelFile (base64Data: string, name: string) {
  if (!base64Data) return

  const mediaType = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,'
  const a = document.createElement('a')
  a.href = mediaType + base64Data
  a.download = `${name}.xlsx`
  a.click()
  return null
}

// Get the user Details from localstorage
export function getUserDetails () {
  const userToken = localStorage.getItem('authUser')
  const userDetails: { companyID: string, token: string, userID: string, username: string } = (userToken ? JSON.parse(userToken) : { companyID: 0, token: '', userID: '', username: '' })
  const config = {
    headers: {
      Authorization: 'Bearer ' + userDetails.token
    }
  }
  return { config, ...userDetails }
}

// Function for navigating to another page using anchor tag
export function pageNavigate (link: string) {
  const a = document.createElement('a')
  a.href = link
  a.click()
  return null
}
// Error Handling function
export function checkErrorMessage (str: string) {
  let error: string[]
  switch (str) {
    case 'Request failed with status code 401':
      error = ['Unauthorized']
      break
    case 'Network Error':
      error = ['CORS Error', 'Please Check your Internet Connection']
      break
    default:
      error = ['Internal Error']
      break
  }
  return error
}
