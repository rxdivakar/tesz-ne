import React from 'react'
import { Button } from 'reactstrap'

interface symbolbuttonType {
  onClick: () => void
  icon: JSX.Element
}

const SymbolButton = (props: symbolbuttonType) => {
  const { onClick, icon } = props
  return (
    <React.Fragment>
      <Button className='p-1 ms-2 symbol-btn' onClick={onClick}>
        {icon}
      </Button>
    </React.Fragment>
  )
}

export default SymbolButton
