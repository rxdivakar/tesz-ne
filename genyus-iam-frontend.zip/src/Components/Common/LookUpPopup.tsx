import React from 'react'
import { ColumnDirective, ColumnsDirective, Filter, GridComponent, Inject, Page, Selection, Sort } from '@syncfusion/ej2-react-grids'
import { Input, Modal, Button } from 'reactstrap'

interface LookUpInterface {
  tableData: any
  tableColumn: Array<{ fieldName: string, headerText: string }>
  multiSelect: boolean
  isOpen: boolean
  close: () => void
  title: string
  showActiveCheckbox: boolean
  currentCheckboxStatus: boolean
  toggleActiveFunction: () => void
  selectFunction: (data: any) => void
}

const LookUpPopup = (props: LookUpInterface) => {
  const { tableData, tableColumn, multiSelect, close, isOpen, title, currentCheckboxStatus, showActiveCheckbox, toggleActiveFunction, selectFunction } = props

  let gridRef: any
  const selectedRow = () => {
    if (gridRef) {
      const selectedindex: any = gridRef.getSelectedRecords()
      selectFunction(selectedindex)
    }
  }
  return (
    <React.Fragment>
      <Modal isOpen={isOpen} size='xl' centered className='overflow-hidden'>
        {/* <ModalHeader className='modal-head'> */}
          <div className='d-flex justify-content-between align-items-center modal-head mb-3'>
            <div className='fs-5'>{title}</div>
            <span onClick={close} className='pointer'><i className="mdi mdi-close-circle fs-4"></i></span>
          </div>
        {/* </ModalHeader> */}
        <div className='h-400'>
            <>
                <GridComponent
                  dataSource={tableData}
                  allowPaging={true}
                  allowFiltering={true}
                  pageSettings={{ pageSize: 6 }}
                  allowSorting={true}
                  ref={(grid) => {
                    gridRef = grid
                    return gridRef
                  }}
                >
                  <ColumnsDirective>
                    { multiSelect
                      ? (
                        <ColumnDirective type='checkbox' width={50} />
                        )
                      : null
                    }
                    {tableColumn.map((data, idx) => (
                      <ColumnDirective
                        key={idx}
                        field={data.fieldName}
                        headerText={data.headerText}
                        width={100}
                      />
                    ))}
                  </ColumnsDirective>
                  <Inject services={[Page, Filter, Sort, Selection]} />
                </GridComponent>
                <div className='d-flex justify-content-between align-items-center p-2' style={{ position: 'sticky', top: '100%', left: 0 }}>
                  { showActiveCheckbox
                    ? <span>
                      <Input id="showActive" type='checkbox' checked={currentCheckboxStatus} onChange={toggleActiveFunction}/>
                      <label className='ms-2 pointer' htmlFor='showActive'>Show only active</label>
                      </span>
                    : null }
                  <div>
                    <Button onClick={selectedRow} disabled={tableData.length === 0}>Select</Button>
                    <Button onClick={close} className='ms-2'>Cancel</Button>
                  </div>
                </div>
              </>
          </div>
      </Modal>
    </React.Fragment>
  )
}

export default LookUpPopup
