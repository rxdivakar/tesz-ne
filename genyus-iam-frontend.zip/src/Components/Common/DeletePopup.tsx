import React from 'react'
import { Input, Modal, ModalHeader, Button } from 'reactstrap'

interface dataObjectTypes {
  id: number
  code: string
  name: string
  hostName?: string
}

interface deletePopupTypes {
  open: boolean
  header: string
  closePopup: () => void
  dataObj: dataObjectTypes
  reasonHandler: (e: React.ChangeEvent<HTMLInputElement>) => void
  proceedFunction: () => void
  reasonValue: string
}

const DeletePopup = (props: deletePopupTypes) => {
  const { open, header, closePopup, dataObj, reasonHandler, reasonValue, proceedFunction } = props
  const fieldName = dataObj?.code || dataObj?.name || dataObj?.hostName
  return (
    <React.Fragment>
      <Modal autoFocus={false} isOpen={open} backdrop='static' id='staticBackdrop' centered>
        <ModalHeader className='modal-head' toggle={closePopup}>
            <div>{ header }</div>
        </ModalHeader>
        <div className="modal-body">
            <p>Are You Sure Want To Delete <span className='text-danger'>{fieldName}</span> This Record?</p>
            <Input autoFocus={true} type='textarea' onChange={(e) => { reasonHandler(e) }} value={reasonValue} placeholder='Enter the Reason for Deletion'/>
        </div>
        <div className="modal-footer">
            <Button type="button" className="btn btn-light" onClick={ closePopup }>Close</Button>
            <Button type="button" className="btn btn-primary" disabled={!(reasonValue)} onClick={ proceedFunction }>Delete</Button>
        </div>
      </Modal>
    </React.Fragment>
  )
}

export default DeletePopup
