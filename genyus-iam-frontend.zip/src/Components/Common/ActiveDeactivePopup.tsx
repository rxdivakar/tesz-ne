import React from 'react'
import { Modal, ModalHeader, Button } from 'reactstrap'

interface ActivateDeactivatePopupTypes {
  open: boolean
  closePopup: () => void
  activeData: any
  submit: (data: any) => void
}

const ActivateDeactivatePopup = (props: ActivateDeactivatePopupTypes) => {
  const { open, closePopup, submit, activeData } = props
  return (
    <React.Fragment>
        <Modal autoFocus={false} isOpen={open} backdrop='static' centered id='staticBackdrop'>
            <ModalHeader toggle={closePopup} className='modal-head'>
                <div>{ activeData?.activeValue === 1 ? 'Deactivation' : 'Activation' }</div>
            </ModalHeader>
            <div className='modal-body'>
                Are you sure to { activeData?.activeValue === 1 ? 'Deactivate' : 'Activate' } &nbsp;
                <span className='text-danger fw-bold'>{ activeData?.name }</span> ?
            </div>
            <div className="modal-footer">
                <Button type="button" color='secondary' onClick={closePopup}>No</Button>
                <Button onClick={submit} color='primary'>Yes</Button>
            </div>
        </Modal>
    </React.Fragment>
  )
}

export default ActivateDeactivatePopup
