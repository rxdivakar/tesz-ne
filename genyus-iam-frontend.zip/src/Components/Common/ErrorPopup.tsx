import React from 'react'
import { Modal, ModalHeader, Button } from 'reactstrap'

interface errorPopupTypes {
  open: boolean
  closePopup?: () => void
  header: string
  content: string | string[]
}

const ErrorPopup = (props: errorPopupTypes) => {
  const { open, closePopup, header, content } = props
  return (
    <React.Fragment>
      <Modal isOpen={open} backdrop='static' centered>
        <ModalHeader toggle={closePopup} className='modal-head'>
          <div>{header}</div>
        </ModalHeader>
        <div className='modal-body p-1'>
        {content && (
            <React.Fragment>
              { Array.isArray(content)
                ? (
                    content.map((data: string, index: number) => (
                      <p className='mb-0 p-2 text-danger' key={index}> {data} </p>
                    ))
                  )
                : (
                   <p className='mb-0 p-2 text-success'>{content}</p>
                  )
              }
            </React.Fragment>
        )}
        </div>
        <div className='text-center my-2'>
          <Button onClick={closePopup}>Close</Button>
        </div>
      </Modal>
    </React.Fragment>
  )
}

export default ErrorPopup
