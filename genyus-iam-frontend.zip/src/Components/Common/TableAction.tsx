import React from 'react'
import { ReactComponent as Log } from '../../assets/icons/Log.svg'
import { ReactComponent as Bin } from '../../assets/icons/delete.svg'
import { ReactComponent as Edit } from '../../assets/icons/edit.svg'
import { ReactComponent as Deactivate } from '../../assets/icons/deactivate.svg'
import { ReactComponent as Activate } from '../../assets/icons/activate.svg'
interface ActionProps {
  triggerEdit?: () => void
  triggerDelete?: () => void
  activeValue?: number
  triggerActive?: () => void
  triggerSideBar?: () => void
  iconList?: string[]
}
const TableAction = (props: ActionProps) => {
  const { activeValue, triggerActive, triggerDelete, triggerEdit, triggerSideBar, iconList = ['edit', 'delete', 'activate', 'eventLog'] } = props
  return (
    <div>
      {
        iconList.includes('edit')
          ? <button className="link fs-4 border-0 bg-transparent" onClick={triggerEdit} title='Edit'>
              <Edit width={16} height={16}/>
            </button>
          : null
      }
      {
        iconList.includes('delete')
          ? <button className="link ms-1 fs-4 border-0  bg-transparent" onClick={triggerDelete} title='Delete'>
              <Bin width={16} height={16}/>
            </button>
          : null
      }
      {
        iconList.includes('activate')
          ? <button className="link ms-1 fs-4 border-0  bg-transparent" onClick={triggerActive} title={activeValue === 0 ? 'Activate' : 'Deactivate'}>
              {
                activeValue === 1
                  ? <Activate width={12} height={12} />
                  : <Deactivate width={12} height={12} className='test'/>
              }
            </button>
          : null
      }
      {
        iconList.includes('eventLog')
          ? <button className="link ms-1 fs-4 border-0  bg-transparent" onClick={triggerSideBar} title='EventLog'>
              <Log width={16} height={16}/>
            </button>
          : null
      }
    </div>
  )
}

export default TableAction
