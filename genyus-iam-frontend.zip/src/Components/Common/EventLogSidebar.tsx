import React, { useState, useEffect } from 'react'
import { Button, Offcanvas, OffcanvasBody, OffcanvasHeader, Spinner } from 'reactstrap'
import EventLog from './EventLog'

interface EventLogTypes {
  isOpen: boolean
  heading: string
  downloadExcelfunction?: () => void
  closeSidebarfunction: () => void
  loader?: boolean
  logData: Array<
  {
    eventDate: string
    comments: string
    eventType: string
    userName: string
    createdDate: number
    createdDateString: string
  }>
}

const EventLogSidebar = (props: EventLogTypes) => {
  const { closeSidebarfunction, downloadExcelfunction, isOpen, logData, heading, loader } = props
  const [eventLog, setEventLog] = useState(logData)

  useEffect(() => {
    setEventLog(logData)
  }, [logData])

  const sortFunction = () => {
    const sortArray = [...eventLog].reverse()
    setEventLog(sortArray)
  }
  return (
    <React.Fragment>
        <Offcanvas isOpen={ isOpen } style={{ overflow: 'auto' }} direction="end" className="right-bar border-0 time-line-sidebar">
            <OffcanvasHeader className='right-bar-head'>
                <div className='d-flex align-items-end justify-content-between '>
                <p className='mb-0'>{ heading }</p>
                <div className='logo-wrapper d-flex gap-3 align-items-end'>
                    <span className='icon' onClick={ downloadExcelfunction }>
                    <i className='mdi mdi-microsoft-excel'></i>
                    </span>
                    <span onClick={ closeSidebarfunction } className='icon'>
                    <i className='mdi mdi-window-close'></i>
                    </span>
                </div>
                </div>
            </OffcanvasHeader>

            <OffcanvasBody className='h-100'>

            { loader
              ? <div className='d-flex p-3 justify-content-center'><Spinner/></div>
              : (logData?.length > 0)
                  ? <React.Fragment>

                        <div className='d-flex justify-content-end align-items-center mb-2'>
                            <p className='mb-0 d-flex align-items-center gap-2 cursor-pointer' onClick={sortFunction}>
                              <i className='mdi mdi-sort icon'></i>
                              Sort
                            </p>
                        </div>

                        <section className='timeline-wrapper'>
                            { eventLog.map((data, index) => {
                              return (
                                <EventLog key={index} {...data}/>
                              )
                            })}
                        </section>

                    </React.Fragment>
                  : <p className='text-center'>No record Found</p>
            }
            </OffcanvasBody>
            <div className="right-bar-end">
              <Button className='m-3' color='danger' outline onClick={ closeSidebarfunction }>Close</Button>
            </div>
        </Offcanvas>
    </React.Fragment>
  )
}

export default EventLogSidebar
