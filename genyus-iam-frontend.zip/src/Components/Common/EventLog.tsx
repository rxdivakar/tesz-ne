import React from 'react'
import moment from 'moment'

interface eventLogTypes {
  eventDate: string
  comments: string
  eventType: string
  userName: string
  createdDate: number
  createdDateString: string
}

const EventLog = (props: eventLogTypes) => {
  const { eventType, userName, createdDate, comments, eventDate } = props
  return (
    <React.Fragment>
      <div className='time-line'>
        <div className='content'>
          <p>{eventType}</p>
          <p>
            {comments}
          </p>

          <div className='time-date d-flex justify-content-between'>
            <p className='d-flex justify-content-between align-items-center'>
              <span>{userName}</span>
            </p>
            <span>{moment(createdDate).format('MMM DD YYYY')} ,{moment(eventDate).format('h:mm:ss a')}</span>
            {/* <span> ,{moment(eventDate).format('h:mm:ss a')}</span> */}
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}

export default EventLog
