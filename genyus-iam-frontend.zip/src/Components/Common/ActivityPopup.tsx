import React from 'react'
import { Input, Modal, ModalHeader, Button } from 'reactstrap'

interface dataObjectTypes {
  id: number
  code?: string
  active?: number
}

interface activityPopupTypes {
  open: boolean
  closePopup: () => void
  dataObj: dataObjectTypes
  reasonHandler: (e: React.ChangeEvent<HTMLInputElement>) => void
  reasonValue: string
  proceedFunction: () => void
}

const ActivityPopup = (props: activityPopupTypes) => {
  const { open, closePopup, dataObj, reasonHandler, reasonValue, proceedFunction } = props
  return (
    <React.Fragment>
        <Modal autoFocus={false} isOpen={open} backdrop='static' centered id='staticBackdrop'>
            <ModalHeader toggle={closePopup} className='modal-head'>
                <div>Enter Reason for { dataObj?.active === 1 ? 'Deactivation' : 'Activation' }</div>
            </ModalHeader>
            <div className='modal-body'>
                <Input autoFocus={true} type='textarea' onChange={(e) => { reasonHandler(e) }} value={reasonValue} placeholder={`Enter the Reason for ${dataObj?.active === 1 ? 'Deactivation' : 'Activation'}`}/>
            </div>
            <div className="modal-footer">
                <Button type="button" onClick={closePopup}>Close</Button>
                <Button onClick={proceedFunction} disabled={!(reasonValue)}>{ dataObj?.active === 1 ? 'Deactivate' : 'Activate' }</Button>
            </div>
        </Modal>
    </React.Fragment>
  )
}

export default ActivityPopup
