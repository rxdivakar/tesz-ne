import React from 'react'
import { Button } from 'reactstrap'

interface HeaderProps {
  title: string
  buttonText?: string
  type: 'index' | 'form-page'
  excelBtnShow?: boolean
  destination?: () => void
  triggerSubmit?: (e) => void
  saveAndGoBackBtn?: () => void
  closeBtn?: () => void
  excelDownload?: () => void
}

const PageHeader = (props: HeaderProps) => {
  const { title, type, buttonText, triggerSubmit, saveAndGoBackBtn, closeBtn, destination, excelDownload, excelBtnShow = true } = props
  return (
        <React.Fragment>
            <div className="px-3 py-1 d-flex justify-content-between align-items-center table-head border rounded-top">
                <p className="mb-0">{ title }</p>
                <div className="d-flex gap-4 align-items-center">
                    { type === 'form-page'
                      ? <>
                        <button className="bg-transparent text-white fs-4 border-0 common-font d-flex" type='submit' onClick={ triggerSubmit } id="form-submit" title='Save'>
                            <i className="bx bx-save"></i>
                        </button>
                        <button className="bg-transparent text-white fs-4 border-0 common-font d-flex" onClick={ saveAndGoBackBtn } title='Save and Go Back'>
                            <i className="bx bx-arrow-back" ></i>
                        </button>
                        <button className="bg-transparent text-white fs-4 border-0 common-font d-flex" onClick={ closeBtn } title='Cancel and Go Back'>
                            <i className="mdi mdi-close-circle"></i>
                        </button>
                       </>
                      : <>
                        { excelBtnShow &&
                            <span className='icon' onClick={excelDownload}>
                            <i className='mdi mdi-microsoft-excel'></i>
                            </span>
                        }
                        <Button className="fs-6 py-1 px-2 border-0 add-btn rounded-2" onClick={destination} >
                            <i className='bx bx-plus font-size-16 align-middle'></i>
                            { buttonText }
                        </Button>
                        </>
                    }
                </div>
            </div>
        </React.Fragment>
  )
}

export default PageHeader
