import axios from 'axios'
import {
  isLoading,
  stopLoading,
  createModuleSlice,
  editModuleSlice
} from './reducer'
import { toast } from 'react-toastify'
import { getProductByIDThunk } from 'slices/product/thunk'

const apiDomain = process.env.REACT_APP_API_ENDPOINT

export const createModuleThunk = (data) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.post(`${apiDomain}/module/create`, data)
    dispatch(createModuleSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error(error?.message)
  }
}

export const updateModulebyIDThunk = (payload, id) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.put(
      `${apiDomain}/module/update/${id}`,
      payload
    )
    console.log({ response })
    dispatch(editModuleSlice(response?.data[0]))
    dispatch(getProductByIDThunk(payload?.product_id))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}
