import { createSlice } from '@reduxjs/toolkit'

interface moduleDataType {
  module_id: string
  module_name: string
  module_desc: string
  module_price: string
  is_active: boolean
}

interface moduleReducerTypes {
  loading: boolean
  module: moduleDataType
  error: []
  modules: moduleDataType[]
}

export const initialState: moduleReducerTypes = {
  loading: false,
  module: {
    module_id: '',
    module_name: '',
    module_desc: '',
    module_price: '',
    is_active: false
  },
  modules: [],
  error: []
}

const moduleSlice = createSlice({
  name: 'module',
  initialState,
  reducers: {
    isLoading (state) {
      state.loading = true
    },
    stopLoading (state) {
      state.loading = false
    },
    createModuleSlice (state, action) {
      state.loading = false
      state.modules = [action.payload, ...state.modules]
    },
    editModuleSlice (state, action) {
      state.loading = false
      state.modules = state.modules.map((i) =>
        i.module_id === action.payload.id ? action.payload : i
      )
    }
  }
})

export const { isLoading, stopLoading, createModuleSlice, editModuleSlice } = moduleSlice.actions

export default moduleSlice.reducer
