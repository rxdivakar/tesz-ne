import { getFirebaseBackend } from 'helpers/firebase_helper'
import { loginSuccess, apiError, logoutUserSuccess, resetLoginFlag, setLoading } from './reducer'

import axios from 'axios'

const apiDomail = process.env.REACT_APP_API_ENDPOINT

const config = {
  headers: {
    'Content-Type': 'application/json'
  }
}

export const loginuser = (user: any, history: any) => async (dispatch: any) => {
  try {
    dispatch(setLoading())

    const response = await axios.post(apiDomail + '/token/generate-token?', {
      username: user.email,
      password: user.password
    }, config)

    const { errors, responseCode } = response

    if (!errors && responseCode === '0') {
      const { result: userInfo } = response
      localStorage.setItem('authUser', JSON.stringify(userInfo))
      dispatch(loginSuccess(userInfo))
      history('/dashboard')
    } else {
      const error = 'Invalid Email or Password'
      dispatch(apiError(error))
    }
  } catch (error) {
    dispatch(apiError(error))
  }
}

export const logoutUser = () => async (dispatch: any) => {
  try {
    localStorage.removeItem('authUser')

    const fireBaseBackend = getFirebaseBackend()
    if (process.env.REACT_APP_DEFAULTAUTH === 'firebase') {
      const response = fireBaseBackend.logout
      dispatch(logoutUserSuccess(response))
    } else {
      dispatch(logoutUserSuccess(true))
    }
  } catch (error) {
    dispatch(apiError(error))
  }
}

export const resetLoginMsgFlag = () => {
  try {
    const response = resetLoginFlag()
    return response
  } catch (error) {
    return error
  }
}

export const socialLogin = (type: any, history: any) => async (dispatch: any) => {
  try {
    let response: any

    if (process.env.REACT_APP_DEFAULTAUTH === 'firebase') {
      const fireBaseBackend = getFirebaseBackend()
      response = fireBaseBackend.socialLoginUser(type)
    }

    const socialdata = await response
    if (socialdata) {
      sessionStorage.setItem('authUser', JSON.stringify(socialdata))
      dispatch(loginSuccess(socialdata))
      history('/dashboard')
    }
  } catch (error) {
    dispatch(apiError(error))
  }
}
