import { createSlice } from '@reduxjs/toolkit'

interface moduleDataType {
  module_id: string
  module_name: string
}

interface productDataType {
  product_id: string
  product_name: string
  product_desc: string
  product_price: string
  is_active: boolean
  modules?: moduleDataType[]
}

interface productReducerTypes {
  loading: boolean
  products: productDataType[]
  product: productDataType
  error: []
}

export const initialState: productReducerTypes = {
  loading: false,
  products: [],
  product: {
    product_id: '',
    product_name: '',
    product_desc: '',
    product_price: '',
    is_active: false,
    modules: []
  },
  error: []
}

const productSlice = createSlice({
  name: 'product',
  initialState,
  reducers: {
    isLoading (state) {
      state.loading = true
    },
    stopLoading (state) {
      state.loading = false
    },
    getAllProductDataSlice (state, action) {
      state.loading = false
      state.products = action.payload
    },
    createProductSlice (state, action) {
      action.payload.modules = []
      state.loading = false
      state.products = [action.payload, ...state.products]
    },
    editProductSlice (state, action) {
      action.payload.modules = []
      state.loading = false
      state.products = state.products.map((i) =>
        i.product_id === action.payload.id ? action.payload : i
      )
    },
    getProductByIDSlice (state, action) {
      state.loading = false
      state.product = action.payload
    }
  }
})

export const {
  isLoading,
  getAllProductDataSlice,
  createProductSlice,
  getProductByIDSlice,
  stopLoading,
  editProductSlice
} = productSlice.actions

export default productSlice.reducer
