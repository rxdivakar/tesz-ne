import axios from 'axios'
import {
  isLoading,
  getAllProductDataSlice,
  createProductSlice,
  getProductByIDSlice,
  stopLoading,
  editProductSlice
} from './reducer'
import { toast } from 'react-toastify'

const apiDomain = process.env.REACT_APP_API_ENDPOINT

export const getProductDataThunk = () => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.get(`${apiDomain}/product/getall`)
    dispatch(getAllProductDataSlice(response?.data))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    toast.error(error?.message)
  }
}

export const createProductThunk = (data) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.post(`${apiDomain}/product/create`, data)
    dispatch(createProductSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error(error?.message)
  }
}

export const getProductByIDThunk = (id) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.get(`${apiDomain}/product/get/${id}`)
    console.log({ response })
    dispatch(getProductByIDSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}

export const updateProductbyIDThunk = (payload, id) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.put(
      `${apiDomain}/product/update/${id}`,
      payload
    )
    console.log({ response })
    dispatch(editProductSlice(response?.data[0]))
    dispatch(getProductDataThunk())
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}
