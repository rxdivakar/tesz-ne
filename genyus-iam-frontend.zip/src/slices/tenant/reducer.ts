import { createSlice } from '@reduxjs/toolkit'

interface tenantDataType {
  tenant_id: string
  tenant_fullname: string
  tenant_displayname: string
  tenant_email: string
  tenant_country: string
  tenant_phone: string
  is_active: boolean
}

interface tenantReducerTypes {
  loading: boolean
  tenants: tenantDataType[]
  tenant: tenantDataType
  error: boolean
}

export const initialState: tenantReducerTypes = {
  loading: false,
  tenants: [],
  tenant: {
    tenant_id: '',
    tenant_fullname: '',
    tenant_displayname: '',
    tenant_email: '',
    tenant_phone: '',
    tenant_country: '',
    is_active: false
  },
  error: false
}

const tenantSlice = createSlice({
  name: 'tenant',
  initialState,
  reducers: {
    isLoading (state) {
      state.loading = true
      state.error = false
    },
    setErrorTrue (state) {
      state.error = true
    },
    stopLoading (state) {
      state.loading = false
      state.error = true
    },
    getAllTenantDataSlice (state, action) {
      state.loading = false
      state.tenants = action.payload
    },
    createTenantSlice (state, action) {
      state.loading = false
      state.tenant = action.payload
      state.tenants = [action.payload, ...state.tenants]
    },
    editTenantSlice (state, action) {
      action.payload.modules = []
      state.loading = false
      state.tenants = state.tenants.map((i) =>
        i.tenant_id === action.payload.id ? action.payload : i
      )
    },
    getTenantByIDSlice (state, action) {
      state.loading = false
      state.tenant = action.payload
    }
  }
})

export const {
  isLoading,
  getAllTenantDataSlice,
  createTenantSlice,
  getTenantByIDSlice,
  stopLoading,
  setErrorTrue,
  editTenantSlice
} = tenantSlice.actions

export default tenantSlice.reducer
