import axios from 'axios'
import {
  isLoading,
  getAllTenantDataSlice,
  createTenantSlice,
  getTenantByIDSlice,
  stopLoading,
  editTenantSlice,
  setErrorTrue
} from './reducer'
import { toast } from 'react-toastify'

const apiDomain = process.env.REACT_APP_API_ENDPOINT

export const getTenantDataThunk = () => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.get(`${apiDomain}/tenant/getall`)
    dispatch(getAllTenantDataSlice(response?.data))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    toast.error(error?.message)
  }
}

export const createTenantThunk = (data) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    dispatch(setErrorTrue())
    const response = await axios.post(`${apiDomain}/tenant/create`, data)
    dispatch(createTenantSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error(error?.message)
  }
}

export const getTenantByIDThunk = (id) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.get(`${apiDomain}/tenant/get/${id}`)
    console.log({ response })
    dispatch(getTenantByIDSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}

export const updateTenantbyIDThunk = (payload) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.put(
      `${apiDomain}/tenant/update/${payload.id}`,
      payload.body
    )
    dispatch(editTenantSlice(response?.data[0]))
    dispatch(getTenantDataThunk())
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}
