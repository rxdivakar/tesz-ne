import axios from 'axios'
import {
  isLoading,
  getAllSubscriptionDataSlice,
  createSubscriptionSlice,
  getSubscriptionByIDSlice,
  stopLoading,
  editSubscriptionSlice
} from './reducer'
import { toast } from 'react-toastify'

const apiDomain = process.env.REACT_APP_API_ENDPOINT

export const getSubscriptionDataThunk = () => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.get(`${apiDomain}/subscription/getall`)
    dispatch(getAllSubscriptionDataSlice(response?.data))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    toast.error(error?.message)
  }
}

export const createSubscriptionThunk = (data, navigate) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.post(`${apiDomain}/subscription/create`, data)
    dispatch(createSubscriptionSlice(response?.data[0]))
    toast.success(response?.message)
    navigate(-1)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error(error?.message)
  }
}

export const getSubscriptionByIDThunk = (id) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.get(`${apiDomain}/subscription/get/${id}`)
    console.log({ response })
    dispatch(getSubscriptionByIDSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}

export const updateSubscriptionbyIDThunk = (payload) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.put(
      `${apiDomain}/subscription/update/${payload.id}`,
      payload.body
    )
    console.log({ response })
    dispatch(editSubscriptionSlice(response?.data[0]))
    dispatch(getSubscriptionDataThunk())
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}
