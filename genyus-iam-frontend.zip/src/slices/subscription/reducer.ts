import { createSlice } from '@reduxjs/toolkit'

interface productTypes {
  product_id: string
  product_name: string
}

interface moduleTypes {
  module_id: string
  module_name: string
}

interface subscriptionDataType {
  subscription_id: string
  subscription_name: string
  is_active: boolean
  products?: productTypes[]
  modules?: moduleTypes[]
}

interface subscriptionReducerTypes {
  loading: boolean
  subscriptions: subscriptionDataType[]
  subscription: subscriptionDataType
  error: []
}

export const initialState: subscriptionReducerTypes = {
  loading: false,
  subscriptions: [],
  subscription: {
    subscription_id: '',
    subscription_name: '',
    is_active: false,
    products: [],
    modules: []
  },
  error: []
}

const subscriptionSlice = createSlice({
  name: 'subscription',
  initialState,
  reducers: {
    isLoading (state) {
      state.loading = true
    },
    stopLoading (state) {
      state.loading = false
    },
    getAllSubscriptionDataSlice (state, action) {
      state.loading = false
      state.subscriptions = action.payload
    },
    createSubscriptionSlice (state, action) {
      action.payload.modules = []
      action.payload.products = []
      state.loading = false
      state.subscriptions = [action.payload, ...state.subscriptions]
    },
    editSubscriptionSlice (state, action) {
      action.payload.modules = []
      state.loading = false
      state.subscriptions = state.subscriptions.map((i) =>
        i.subscription_id === action.payload.id ? action.payload : i
      )
    },
    getSubscriptionByIDSlice (state, action) {
      state.loading = false
      state.subscription = action.payload
    }
  }
})

export const {
  isLoading,
  getAllSubscriptionDataSlice,
  createSubscriptionSlice,
  getSubscriptionByIDSlice,
  stopLoading,
  editSubscriptionSlice
} = subscriptionSlice.actions

export default subscriptionSlice.reducer
