import { createSlice } from '@reduxjs/toolkit'

interface subscribed_tenantDataType {
  subscription_id: string
  tenant_id: string
  is_active: boolean
  start_date: string
  end_date: string
  payment_id: string
  subscription_type: string
}

interface subscribed_tenantReducerTypes {
  loading: boolean
  subscribed_tenant: subscribed_tenantDataType
  error: []
}

export const initialState: subscribed_tenantReducerTypes = {
  loading: false,
  subscribed_tenant: {
    subscription_id: '',
    tenant_id: '',
    is_active: true,
    start_date: '',
    end_date: '',
    payment_id: '',
    subscription_type: ''
  },
  error: []
}

const subscribedTenantSlice = createSlice({
  name: 'subscribed_tenant',
  initialState,
  reducers: {
    isLoading (state) {
      state.loading = true
    },
    stopLoading (state) {
      state.loading = false
    },
    createSubscribedTenantSlice (state, action) {
      state.loading = false
      state.subscribed_tenant = action.payload
    },
    editSubscribedTenantSlice (state, action) {
      state.loading = false
      state.subscribed_tenant = action.payload
    },
    getSubscribedTenantByIDSlice (state, action) {
      state.loading = false
      state.subscribed_tenant = action.payload
    }
  }
})

export const {
  isLoading,
  createSubscribedTenantSlice,
  getSubscribedTenantByIDSlice,
  stopLoading,
  editSubscribedTenantSlice
} = subscribedTenantSlice.actions

export default subscribedTenantSlice.reducer
