import axios from 'axios'
import {
  isLoading,
  createSubscribedTenantSlice,
  getSubscribedTenantByIDSlice,
  stopLoading,
  editSubscribedTenantSlice
} from './reducer'
import { toast } from 'react-toastify'

const apiDomain = process.env.REACT_APP_API_ENDPOINT

export const createSubscribedTenantThunk = (data) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.post(`${apiDomain}/subscriptiontenant/create`, data)
    dispatch(createSubscribedTenantSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error(error?.message)
  }
}

export const getSubscribedTenantByIDThunk = (id) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.get(`${apiDomain}/subscriptiontenant/get/${id}`)
    console.log({ response })
    dispatch(getSubscribedTenantByIDSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}

export const updateSubscribedTenantbyIDThunk = (payload) => async (dispatch: any) => {
  try {
    dispatch(isLoading())
    const response = await axios.put(
      `${apiDomain}/subscriptiontenant/update/${payload.id}`,
      payload.body
    )
    console.log({ response })
    dispatch(editSubscribedTenantSlice(response?.data[0]))
    toast.success(response?.message)
  } catch (error: any) {
    console.log(error)
    dispatch(stopLoading())
    toast.error('Error')
  }
}
