import Dashboard from '../pages/Dashboard'
import Product from 'pages/Products/ProductListing'
import ViewProduct from 'pages/Products/ViewProduct'
import Tenant from 'pages/Customers/customersPage'
import Subscriptions from 'pages/Subscription/subscriptionPage'
import AddSubscription from 'pages/Subscription/AddSubscription'

// Auth
import Login from 'pages/Authentication/login'
import Logout from 'pages/Authentication/Logout'
import UserProfile from 'pages/Authentication/user-profile'
import ForgotPassword from 'pages/Authentication/ForgotPassword'
import SignUp from 'pages/Authentication/Register'
import PageNotFound from 'pages/404.page'
import AddCustomer from 'pages/Customers/AddCustomer'
import AddProd from 'pages/Products/AddProd'
import EditProd from 'pages/Products/EditProd'
import AddModule from 'pages/Products/AddModule'
import EditModule from 'pages/Products/EditModule'

const authProtectedRoutes = [
  { path: '/dashboard', component: <Dashboard /> },
  { path: '/profile', component: <UserProfile /> },
  { path: '/customer', component: <Tenant /> },
  { path: '/product', component: <Product /> },
  { path: '/add-product', component: <AddProd /> },
  { path: '/edit-product', component: <EditProd /> },
  { path: '/product/:id', component: <ViewProduct /> },
  { path: '/product/:id/add-module', component: <AddModule /> },
  { path: '/product/:id/edit-module', component: <EditModule /> },
  { path: '/subscriptions', component: <Subscriptions /> },
  { path: '/add-subscription', component: <AddSubscription /> },
  { path: '/customer/add', component: <AddCustomer /> }
]

const publicRoutes = [
  { path: '/login', component: <Login /> },
  { path: '/', component: <Login /> },
  { path: '/logout', component: <Logout /> },
  { path: '/forgot-password', component: <ForgotPassword /> },
  { path: '/register', component: <SignUp /> },
  { path: '*', component: <PageNotFound /> }
]
export { authProtectedRoutes, publicRoutes }
