import React, { useEffect } from 'react'
import DataTable from 'react-data-table-component'
import {
  // FaTrashAlt,
  FaEdit
} from 'react-icons/fa'
import { useDispatch, useSelector } from 'react-redux'
import Spinners from 'Components/Common/Spinner'
import { Link, useNavigate } from 'react-router-dom'
import { getSubscriptionDataThunk } from 'slices/subscription/thunk'

interface SubscriptionData {
  index: any
  products: any
  modules: any
}

const SubscriptionPage = () => {
  const dispatch = useDispatch<any>()
  const navigate = useNavigate()

  useEffect(() => {
    dispatch(getSubscriptionDataThunk())
  }, [dispatch, getSubscriptionDataThunk])

  const { subscriptions, loading } = useSelector(
    (state: any) => state.Subscription
  )
  const columns = [
    {
      name: 'S.No.',
      selector: (row, index: any) => index + 1,
      sortable: true
    },
    {
      name: 'Subscription Name',
      selector: (row) => {
        return (
          <Link to={`/product/${row.subscription_id}`}>
            {row.subscription_name}
          </Link>
        )
      },
      sortable: true
    },
    {
      name: 'Subscription Description',
      selector: (row) => <div>Descriptions</div>,
      sortable: true
    },
    {
      name: 'Subscribed Products',
      selector: (row, index: any) => {
        return row.products_data?.map((product) => {
          return <div key={index}>{product?.product_name}</div>
        })
      },

      sortable: true
    },
    {
      name: 'Subscribed Moudles',
      selector: (row, index: any) => {
        return row.modules_data?.map((module) => {
          return <div key={index}>{module?.module_name}</div>
        })
      },

      sortable: true
    },
    {
      name: 'Type',
      selector: (row) => {
        return <div>{row.subscription_type}</div>
      },
      sortable: true
    },
    {
      name: 'Actions',
      cell: (row) => (
        <div>
          <button
            className='btn btn-secondary me-2'
            onClick={() => {
              console.log('Edit')
            }}
          >
            <FaEdit />
          </button>
        </div>
      ),
      ignoreRowClick: true,
      allowOverflow: true,
      button: true
    }
  ]

  if (loading) {
    return <Spinners />
  }

  return (
    <React.Fragment>
      <div className='page-content'>
        <div className='full-page'>
          <div className=' p-3 pb-2' style={{ color: 'black' }}>
            <h3 className='text-2xl mb-0' style={{ fontWeight: '500' }}>
              Subscription Listing
            </h3>
          </div>
          <section>
            <DataTable<SubscriptionData>
              columns={columns}
              data={subscriptions}
              // data={filteredProductDetails}
              striped
              responsive
              pagination
              paginationPerPage={10}
              paginationRowsPerPageOptions={[10, 20, 30, 40]}
              paginationComponentOptions={{
                rowsPerPageText: 'Rows per page:'
              }}
              paginationTotalRows={subscriptions?.length}
              defaultSortAsc={true}
              paginationServer={false}
              expandableRows={false}
              expandOnRowClicked={false}
              fixedHeader
              fixedHeaderScrollHeight='calc(100vh - 100px)'
              keyField='index'
              customStyles={{
                headRow: {
                  style: {
                    background: '#f2f2f2'
                  }
                },
                subHeader: {
                  style: {
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexWrap: 'nowrap'
                  }
                }
              }}
              subHeader
              subHeaderComponent={
                <>
                  <div className='d-flex'>
                    <input
                      style={{ width: '400px' }}
                      type='text'
                      placeholder='Search...'
                      className='form-control me-2'
                      onChange={(e) => {
                        console.log(e.target.value)
                        // (e.target.value)
                      }}
                    />
                    <div className='d-flex justify-content-between align-items-center products-retry'>
                      <i
                        className='fas fa-undo'
                        onClick={() => {
                          dispatch(getSubscriptionDataThunk())
                        }}
                      ></i>{' '}
                    </div>
                  </div>

                  <div>
                    {' '}
                    <button
                      onClick={() => {
                        console.log('Export to CSV')
                      }}
                      className='btn  me-2 text-white '
                      style={{ background: '#74788d' }}
                    >
                      CSV Download
                    </button>
                    <button
                      onClick={() => {
                        // addToggle()
                        // setEditData({})
                        navigate('/add-subscription')
                      }}
                      // onClick={toggleCanvas}
                      className='btn  text-white me-2'
                      style={{ background: '#74788d' }}
                    >
                      + Add Subscriptions
                    </button>
                  </div>
                </>
              }
              contextActions={<div>Edit/Delete context menu</div>}
              contextMessage={{ singular: 'item', plural: 'items' }}
              // onRowClicked={(row) => {
              //   toggleCanvas(row, 'View')
              // }}
              onSelectedRowsChange={(selectedRows) => {
                console.log(selectedRows.selectedRows)
              }}
              clearSelectedRows
              selectableRows={false} // Disable selectable rows
            />
          </section>
        </div>
      </div>
    </React.Fragment>
  )
}

export default SubscriptionPage
