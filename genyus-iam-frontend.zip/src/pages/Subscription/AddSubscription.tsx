import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  Input,
  Label,
  Row
} from 'reactstrap'
import { FaTrash } from 'react-icons/fa'
import Select from 'react-select'
import { getProductDataThunk } from 'slices/product/thunk'
import { createSubscriptionThunk } from 'slices/subscription/thunk'
import { useNavigate } from 'react-router-dom'

const AddSubscription = () => {
  const dispatch = useDispatch<any>()
  const navigate = useNavigate()
  const [moduleOpt, setModuleOpt] = useState([])
  useEffect(() => {
    dispatch(getProductDataThunk())
  }, [dispatch])

  const { products } = useSelector((state: any) => state.Product)

  const [formData, setFormData] = useState({
    subscription_name: '',
    products: [],
    modules: [],
    is_active: true,
    subscription_type: 'paid',
    subscription_description: ''
  })

  const productOptions = products.map((item) => ({
    label: item.product_name,
    value: item.product_id
  }))

  const [inputFields, setInputFields] = useState([
    {
      product: '',
      modules: [],
      productOptions: productOptions,
      moduleOptions: []
    }
  ])

  const [selectedProducts, setSelectedProducts] = useState<any>([])

  const addFields = () => {
    const newField = {
      product: formData.products,
      modules: formData.modules
    }

    setSelectedProducts([...selectedProducts, newField])

    // Reset only the form-related state
    setFormData({
      subscription_name: formData.subscription_name,
      products: [],
      modules: [],
      is_active: formData.is_active,
      subscription_type: formData.subscription_type,
      subscription_description: formData.subscription_description
    })
    setModuleOpt([])
    setInputFields([
      ...inputFields,
      {
        product: '',
        modules: [],
        productOptions: productOptions,
        moduleOptions: []
      }
    ])
  }

  const handleModuleChange = (value) => {
    setFormData({ ...formData, modules: value })
  }

  const onSubmit = (e) => {
    e.preventDefault()
    const allProducts: any = []
    const allModules: any = []
    selectedProducts.forEach((item) => {
      allProducts.push(item.product.value)
      item.modules.forEach((module) => allModules.push(module.value))
    })
    const transformedData = {
      subscription_name: formData.subscription_name,
      products: allProducts,
      modules: allModules,
      is_active: formData.is_active,
      subscription_type: formData.subscription_type,
      subscription_description: formData.subscription_description
    }
    dispatch(createSubscriptionThunk(transformedData, navigate))
  }

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleProductChange = (value) => {
    const productId = value.value
    const isProductSelected = selectedProducts.some(
      (item) => item.product.value === productId
    )
    if (!isProductSelected) {
      setFormData({ ...formData, products: value })
      const product = products.find(
        (product) => product.product_id === productId
      )
      const moduleOptions = product.modules.map((item) => ({
        label: item.module_name,
        value: item.module_id
      }))
      setModuleOpt(moduleOptions)
    }
  }

  const handleDelete = (index) => {
    const updatedSelectedProducts = [...selectedProducts]
    updatedSelectedProducts.splice(index, 1)
    setSelectedProducts(updatedSelectedProducts)
  }

  return (
    <React.Fragment>
      <div className='page-content'>
        <div className='full-page'>
          <div className=' p-3 pb-2' style={{ color: 'black' }}>
            <h3 className='text-2xl mb-0' style={{ fontWeight: '500' }}>
              Create Subscription
            </h3>
          </div>
          <section>
            <Row>
              <Col xl={9}>
                <Card>
                  <CardBody>
                    <Form onSubmit={onSubmit}>
                      <Row className='mb-4'>
                        <Label
                          htmlFor='horizontal-firstname-Input'
                          className='col-sm-2 col-form-label'
                        >
                          Subscription Name
                        </Label>
                        <Col sm={8}>
                          <Input
                            name='subscription_name'
                            type='text'
                            className='form-control'
                            id='horizontal-firstname-Input'
                            placeholder='Enter Subscription Name'
                            value={formData.subscription_name}
                            onChange={onChange}
                          />
                        </Col>
                      </Row>
                      <Row className='mb-4'>
                        <Label
                          htmlFor='horizontal-firstname-Input'
                          className='col-sm-2 col-form-label'
                        >
                          Description
                        </Label>
                        <Col sm={8}>
                          <Input
                            name='subscription_description'
                            type='text'
                            className='form-control'
                            id='horizontal-firstname-Input'
                            placeholder='Enter Description'
                            value={formData.subscription_description}
                            onChange={onChange}
                          />
                        </Col>
                      </Row>
                      <Row className='mb-4'>
                        <Label
                          htmlFor='horizontal-firstname-Input'
                          className='col-sm-2 col-form-label'
                        >
                          Product
                        </Label>
                        <Col sm={3}>
                          <Select
                            id='show'
                            name='show'
                            // isMulti={true}
                            placeholder='Select Products'
                            options={productOptions}
                            value={formData.products}
                            onChange={(value) => {
                              handleProductChange(value)
                            }}
                            classNamePrefix='mySelect'
                          />
                        </Col>
                        <Label
                          htmlFor='horizontal-firstname-Input'
                          className='col-sm-2 col-form-label'
                        >
                          Modules
                        </Label>
                        <Col sm={3}>
                          <Select
                            id='show'
                            name='show'
                            isMulti={true}
                            placeholder='Select Modules'
                            options={moduleOpt}
                            value={formData.modules}
                            onChange={(value) => {
                              handleModuleChange(value)
                            }}
                            classNamePrefix='mySelect'
                          />
                        </Col>
                        <Col>
                          <div className='d-flex justify-content-end m-1 float-right'>
                            <button
                              type='button'
                              className='btn btn-soft-info'
                              onClick={() => {
                                addFields()
                              }}
                            >
                              <i className='bx bx-plus font-size-16 align-middle me-2'></i>{' '}
                              Add Product
                            </button>
                          </div>
                        </Col>
                      </Row>

                      {/* Render the table */}
                      {selectedProducts.length > 0 && (
                        <section>
                          <div className='mt-4'>
                            <h4>Selected Products and Modules:</h4>
                            <table className='table table-bordered'>
                              <thead>
                                <tr>
                                  <th>Product</th>
                                  <th>Modules</th>
                                  <th>Action</th>{' '}
                                  {/* Add a new column for actions */}
                                </tr>
                              </thead>
                              <tbody>
                                {selectedProducts.map((item, index) => {
                                  return (
                                    <tr key={index}>
                                      <td>{item.product.label}</td>
                                      <td>
                                        {item.modules
                                          .map((module) => module.label)
                                          .join(', ')}
                                      </td>
                                      <td>
                                        <button
                                          type='button'
                                          className='btn btn-danger btn-sm'
                                          onClick={() => {
                                            handleDelete(index)
                                          }}
                                        >
                                          <FaTrash />
                                        </button>
                                      </td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            </table>
                          </div>
                        </section>
                      )}
                      <Row>
                        <Col sm={12}>
                          <div className='d-flex float-end mt-3'>
                            <Button
                              type='submit'
                              color='primary'
                              className='w-md'
                            >
                              Create
                            </Button>

                            <Button
                              color='secondary'
                              className='ms-1 w-md'
                              onClick={() => {
                                navigate(-1)
                              }}
                            >
                              Cancel
                            </Button>
                          </div>
                        </Col>
                      </Row>
                    </Form>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </section>
        </div>
      </div>
    </React.Fragment>
  )
}

export default AddSubscription
