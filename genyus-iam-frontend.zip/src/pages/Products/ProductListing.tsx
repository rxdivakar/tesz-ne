import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component'
import {
  // FaTrashAlt,
  FaEdit
} from 'react-icons/fa'
import DeleteProd from './DeleteProd'
import { useDispatch, useSelector } from 'react-redux'
import {
  getProductDataThunk,
  updateProductbyIDThunk
} from 'slices/product/thunk'
import Spinners from 'Components/Common/Spinner'
import { Link, useNavigate } from 'react-router-dom'
import './product-listing.scss'
import ActivateDeactivatePopup from 'Components/Common/ActiveDeactivePopup'

interface ProductData {
  index: any
  modules: any
}

const Product: React.FC = () => {
  const dispatch = useDispatch<any>()
  const navigate = useNavigate()
  useEffect(() => {
    dispatch(getProductDataThunk())
  }, [dispatch, getProductDataThunk])

  const { products, loading } = useSelector((state: any) => state.Product)
  const [activityPopupOpen, setActivityPopupOpen] = useState<boolean>(false)
  const [activeValue, setActiveValue] = useState<number>()
  const [activeData, setActiveData] = useState<any>()

  const toggleActivation = () => {
    const active = activeData.is_active
    const body = { ...activeData }
    body.is_active = !active

    dispatch(updateProductbyIDThunk(body, activeData.product_id))
    setActivityPopupOpen(false)
  }

  const columns = [
    {
      name: 'S.No.',
      selector: (row: ProductData, index: any) => index + 1,
      sortable: true
    },
    {
      name: 'Product Name',
      selector: (row) => {
        return <Link to={`/product/${row.product_id}`}>{row.product_name}</Link>
      },
      sortable: true
    },
    {
      name: 'Product Description',
      selector: (row) => row.product_desc,
      sortable: true
    },
    {
      name: 'Activate/Deactivate',
      selector: (row) => {
        return (
          <div className='form-check form-switch mb-3 d-flex align-items-center justify-content-center'>
            <input
              type='checkbox'
              className='form-check-input'
              id='customSwitchsizesm'
              checked={row.is_active}
              onClick={() => {
                // update api to activate/deactivate
                const number = row.is_active ? 1 : 0
                setActiveValue(number)
                setActiveData(row)
                setActivityPopupOpen(true)
                console.log(row.is_active)
              }}
            />
          </div>
        )
      },
      sortable: true
    },
    {
      name: 'Modules',
      selector: (row: ProductData, index: any) => {
        return row.modules?.map((module) => {
          return <div key={index}>{module?.module_name}</div>
        })
      },

      sortable: true
    },
    {
      name: 'Actions',
      cell: (row) => (
        <div>
          <button
            className='btn btn-secondary me-2'
            onClick={() => {
              // setEditData(row)
              // editToggle()
              console.log(row)
              navigate('/edit-product', { state: row })
            }}
          >
            <FaEdit />
          </button>
        </div>
      ),
      ignoreRowClick: true,
      allowOverflow: true,
      button: true
    }
  ]

  const [id] = useState(0)

  const [delModal] = useState(false)

  if (loading) {
    return <Spinners />
  }

  return (
    <React.Fragment>
      <div className='page-content'>
        <>
          <div className='full-page'>
            <div className=' p-3 pb-2' style={{ color: 'black' }}>
              <h3 className='text-2xl mb-0' style={{ fontWeight: '500' }}>
                Product
              </h3>
            </div>
            <section>
              <DataTable<ProductData>
                columns={columns}
                data={products}
                // data={filteredProductDetails}
                striped
                responsive
                pagination
                paginationPerPage={10}
                paginationRowsPerPageOptions={[10, 20, 30, 40]}
                paginationComponentOptions={{
                  rowsPerPageText: 'Rows per page:'
                }}
                paginationTotalRows={products?.length}
                defaultSortAsc={true}
                paginationServer={false}
                expandableRows={false}
                expandOnRowClicked={false}
                fixedHeader
                fixedHeaderScrollHeight='calc(100vh - 100px)'
                keyField='index'
                customStyles={{
                  headRow: {
                    style: {
                      background: '#f2f2f2'
                    }
                  },
                  subHeader: {
                    style: {
                      display: 'flex',
                      justifyContent: 'space-between',
                      flexWrap: 'nowrap'
                    }
                  }
                }}
                subHeader
                subHeaderComponent={
                  <>
                    <div className='d-flex'>
                      <input
                        style={{ width: '400px' }}
                        type='text'
                        placeholder='Search...'
                        className='form-control me-2'
                        onChange={(e) => {
                          console.log(e.target.value)
                          // (e.target.value)
                        }}
                      />
                      <div className='d-flex justify-content-between align-items-center products-retry'>
                        <i
                          className='fas fa-undo'
                          onClick={() => {
                            dispatch(getProductDataThunk())
                          }}
                        ></i>{' '}
                      </div>
                    </div>

                    <div>
                      {' '}
                      <button
                        onClick={() => {
                          console.log('Export to CSV')
                        }}
                        className='btn  me-2 text-white '
                        style={{ background: '#74788d' }}
                      >
                        CSV Download
                      </button>
                      <button
                        onClick={() => {
                          // addToggle()
                          // setEditData({})
                          navigate('/add-product')
                        }}
                        // onClick={toggleCanvas}
                        className='btn  text-white me-2'
                        style={{ background: '#74788d' }}
                      >
                        + Add Product
                      </button>
                    </div>
                  </>
                }
                contextActions={<div>Edit/Delete context menu</div>}
                contextMessage={{ singular: 'item', plural: 'items' }}
                // onRowClicked={(row) => {
                //   toggleCanvas(row, 'View')
                // }}
                onSelectedRowsChange={(selectedRows) => {
                  console.log(selectedRows.selectedRows)
                }}
                clearSelectedRows
                selectableRows={false} // Disable selectable rows
              />
            </section>
          </div>
          {/* <AddProd
            modal={addModal}
            toggle={() => {
              setAddModal(!addModal)
            }}
          /> */}
          <ActivateDeactivatePopup
          open={activityPopupOpen}
          closePopup={() => { setActivityPopupOpen(false) }}
          submit={toggleActivation}
          activeData={{ activeValue, name: activeData?.product_name }}
          />
          {/* <EditProd
            modal={editModal}
            editData={editData}
            toggle={() => {
              setEditModal(!editModal)
            }}
          /> */}
          {delModal && (
            <DeleteProd
              modal={delModal}
              toggle={() => {
                console.log('clicked')
              }}
              id={id}
            />
          )}
        </>
      </div>
    </React.Fragment>
  )
}
export default Product
