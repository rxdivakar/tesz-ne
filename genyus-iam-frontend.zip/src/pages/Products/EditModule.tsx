import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  Input,
  Label,
  Row
} from 'reactstrap'
import { updateModulebyIDThunk } from 'slices/module/thunk'

const EditModule = () => {
  const dispatch = useDispatch<any>()
  const navigate = useNavigate()
  const params = useParams()
  const location = useLocation()
  const [data, setData] = useState(
    {
      module_name: location?.state?.module_name,
      is_active: location?.state?.is_active,
      module_desc: location?.state?.module_desc,
      module_price: location?.state?.module_price,
      product_id: location?.state?.product_id
    }
  )
  const formHandler = (label, value) => {
    setData((data) => {
      return { ...data, [label]: value }
    })
  }
  const resetData = () => {
    setData({
      module_name: '',
      is_active: true,
      module_desc: '',
      module_price: '',
      product_id: location?.state?.product_id
    })
  }
  const onsubmit = () => {
    dispatch(updateModulebyIDThunk(data, location?.state?.module_id))
    navigate(`/product/${params?.id}`)
  }
  return (
    <>
      <React.Fragment>
        <div className='page-content'>
          <div className='full-page'>
            <div className=' p-3 pb-2' style={{ color: 'black' }}>
              <h3 className='text-2xl mb-0' style={{ fontWeight: '500' }}>
                Create Product
              </h3>
            </div>
            <section>
              <Row>
                <Col xl={9}>
                  <Card>
                    <CardBody>
                      <Form
                        onSubmit={(e) => {
                          e.preventDefault()
                          resetData()
                          onsubmit()
                        }}>
                        <Row className='mb-4'>
                          <Label className='block mt-3 ' htmlFor='product_id'>
                            Module Name
                          </Label>
                          <Col sm={8}>
                            <Input
                              // required
                              className=' w-full rounded-md border-gray-300'
                              id='module_name'
                              type='text'
                              value={data.module_name}
                              onChange={(e) => {
                                formHandler('module_name', e.target.value)
                              }}
                            />
                          </Col>
                        </Row>
                        <Row className='mb-2'>
                        <Col sm={8}>
                          <Label className='block' htmlFor='product_id'>
                            Is Active ?
                          </Label>
                        </Col>
                          <Col sm={8}>
                            <div className='form-check form-switch mb-3'>
                              <input
                                type='checkbox'
                                className='form-check-input'
                                id='customSwitchsizesm'
                                checked={data.is_active}
                                onClick={() => {
                                  formHandler('is_active', !data.is_active)
                                }}
                              />
                            </div>
                            {/* <Input
                              // required
                              className='w-full rounded-md border-gray-300'
                              id='module_name'
                              type='select'
                              value={data.is_active}
                              onChange={(e) => {
                                formHandler('is_active', e.target.value)
                              }}
                            >
                              <option value=''>Select</option>
                              <option value='true'>Yes</option>
                              <option value='false'>No</option>
                            </Input> */}
                          </Col>
                        </Row>
                        <Row className='mb-4'>
                          <Label className='block' htmlFor='product_id'>
                            Product Description
                          </Label>
                          <Col sm={8}>
                            <Input
                              // required
                              className='mt-1 w-full rounded-md border-gray-300'
                              id='module_name'
                              type='textarea'
                              value={data.module_desc}
                              onChange={(e) => {
                                formHandler('module_desc', e.target.value)
                              }}
                            />
                          </Col>
                        </Row>
                        <Row className='mb-4'>
                          <Label className='block' htmlFor='module_price'>
                            Module Price
                          </Label>
                          <Col sm={8}>
                            <Input
                              // required
                              className='mt-1 w-full rounded-md border-gray-300'
                              id='module_price'
                              type='text'
                              value={data.module_price}
                              onChange={(e) => {
                                formHandler('module_price', e.target.value)
                              }}
                            />
                          </Col>
                        </Row>

                        <Row>
                          <Col sm={9}>
                            <div className=' d-flex gap-2'>
                              <Button color='primary' type='submit'>
                                Submit
                              </Button>{' '}
                              <Button
                                color='secondary'
                                onClick={() => {
                                  navigate(`/product/${params?.id}`)
                                }}
                              >
                                Cancel
                              </Button>
                            </div>
                          </Col>
                        </Row>
                      </Form>
                    </CardBody>
                  </Card>
                </Col>
              </Row>
            </section>
          </div>
        </div>
      </React.Fragment>
    </>
  )
}

export default EditModule
