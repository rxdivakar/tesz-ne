import React from 'react'

const AddProdModal = () => {
  return <div></div>
}

export default AddProdModal
