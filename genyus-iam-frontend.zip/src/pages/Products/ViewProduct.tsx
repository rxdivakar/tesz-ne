import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import Spinners from 'Components/Common/Spinner'
import { getProductByIDThunk } from 'slices/product/thunk'
import { useNavigate, useParams } from 'react-router-dom'
import { FaEdit } from 'react-icons/fa'
import DataTable from 'react-data-table-component'
import classNames from 'classnames'
import {
  Card,
  CardBody,
  CardTitle,
  Col,
  Nav,
  NavItem,
  NavLink,
  Row
} from 'reactstrap'
import Welcomeback from './Welcomeback'
import StackedColumnChart from './StackedColumnChart'
import ActivateDeactivatePopup from 'Components/Common/ActiveDeactivePopup'
import { updateModulebyIDThunk } from 'slices/module/thunk'
// import { Breadcrumb, Container } from 'reactstrap'

interface ModuleData {
  index: any
  modules: any
  module_permissions: any
}

const ViewProduct = () => {
  const dispatch = useDispatch<any>()
  const navigate = useNavigate()
  const params = useParams()
  const [activityPopupOpen, setActivityPopupOpen] = useState<boolean>(false)
  const [activeValue, setActiveValue] = useState<number>()
  const [activeData, setActiveData] = useState<any>()

  const toggleActivation = () => {
    const active = activeData.is_active
    const body = { ...activeData, product_id: params?.id }
    body.is_active = !active

    dispatch(updateModulebyIDThunk(body, activeData.module_id))
    setActivityPopupOpen(false)
  }

  useEffect(() => {
    dispatch(getProductByIDThunk(params.id))
  }, [dispatch])

  const { product, loading } = useSelector((state: any) => state.Product)
  // const [searchField, setSearchField] = useState('')

  // const filteredModuleDetails = product?.modules.filter((module: any) => {
  //   return module.module_name
  //     ?.toLowerCase()
  //     .includes(searchField?.toLowerCase())
  // })
  // console.log({ filteredModuleDetails })

  const chartsData = [
    {
      name: 'Module A',
      data: [44, 55, 41, 67, 22, 43, 36, 52, 24, 18, 36, 48]
    },
    {
      name: 'Module B',
      data: [13, 23, 20, 8, 13, 27, 18, 22, 10, 16, 24, 22]
    },
    {
      name: 'Module C',
      data: [11, 17, 15, 15, 21, 14, 11, 18, 17, 12, 20, 18]
    }
  ]

  const [periodData, setPeriodData] = useState<any>([])
  const [periodType, setPeriodType] = useState<string>('yearly')

  useEffect(() => {
    setPeriodData(chartsData)
  }, [chartsData])

  const onChangeChartPeriod = (pType: any) => {
    setPeriodType(pType)
  }

  if (loading) {
    return <Spinners />
  }

  const reports = [
    {
      title: 'Total Customers',
      iconClass: 'bx-copy-alt',
      description: '1,235'
    },
    {
      title: 'Active Customers',
      iconClass: 'bx-archive-in',
      description: '600'
    },
    {
      title: 'Inactive Customers',
      iconClass: 'bx-purchase-tag-alt',
      description: '635'
    }
  ]

  const columns = [
    {
      name: 'S.No.',
      selector: (row: ModuleData, index: any) => index + 1,
      sortable: true
    },
    {
      name: 'Module Name',
      selector: (row) => row.module_name,
      sortable: true
    },
    {
      name: 'Module Description',
      selector: (row) => row.module_desc,
      sortable: true
    },
    {
      name: 'Module Price',
      selector: (row) => row.module_price,
      sortable: true
    },
    {
      name: 'Activate/Deactivate',
      selector: (row) => {
        return (
          <div className='form-check form-switch mb-3 d-flex align-items-center justify-content-center'>
            <input
              type='checkbox'
              className='form-check-input'
              id='customSwitchsizesm'
              checked={row.is_active}
              onClick={(e) => {
                const number = row.is_active ? 1 : 0
                setActiveValue(number)
                setActiveData(row)
                setActivityPopupOpen(true)
              }}
            />
          </div>
        )
      },
      sortable: true
    },
    {
      name: 'Module Permissions',
      selector: (row: ModuleData, index: any) => {
        return row.module_permissions?.map((module) => {
          return <div key={index}>{module}</div>
        })
      },

      sortable: true
    },
    {
      name: 'Actions',
      cell: (row) => (
        <div>
          <button
            className='btn btn-secondary me-2'
            onClick={() => {
              navigate(`/product/${params?.id}/edit-module`, { state: row })
            }}
          >
            <FaEdit />
          </button>
        </div>
      ),
      ignoreRowClick: true,
      allowOverflow: true,
      button: true
    }
  ]

  return (
    <React.Fragment>
      <div className='page-content'>
        <div className=' p-3 pb-2' style={{ color: 'black' }}>
          <h3 className='text-2xl mb-0' style={{ fontWeight: '500' }}>
            {product.product_name}
          </h3>

          <section className='m-1 pt-1'>
            <Row>
              <Col xl={4}>
                <Welcomeback
                  productTitle={product?.product_name}
                  description={product?.product_desc}
                />
                {/* <MonthlyEarning /> */}
              </Col>
              <Col xl={8}>
                <Row>
                  {/* Reports Render */}
                  {(reports || []).map((report: any, key: number) => (
                    <Col md={4} key={'_col_' + key}>
                      <Card className='mini-stats-wid'>
                        <CardBody>
                          <div className='d-flex'>
                            <div className='flex-grow-1'>
                              <p className='text-muted fw-medium'>
                                {' '}
                                {report.title}{' '}
                              </p>
                              <h4 className='mb-0'>{report.description}</h4>
                            </div>
                            <div className='avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon'>
                              <span className='avatar-title rounded-circle bg-primary'>
                                <i
                                  className={
                                    'bx ' + report.iconClass + ' font-size-24'
                                  }
                                ></i>
                              </span>
                            </div>
                          </div>
                        </CardBody>
                      </Card>
                    </Col>
                  ))}
                </Row>
                <Card>
                  <CardBody>
                    <div className='d-sm-flex flex-wrap'>
                      <CardTitle tag='h4' className='mb-4'>
                        Product Module Subscriptions
                      </CardTitle>
                      <div className='ms-auto'>
                        <Nav pills>
                          <NavItem>
                            <NavLink
                              href='#'
                              className={classNames(
                                { active: periodType === 'weekly' },
                                'nav-link'
                              )}
                              onClick={() => {
                                onChangeChartPeriod('weekly')
                              }}
                              id='one_month'
                            >
                              Week
                            </NavLink>
                          </NavItem>
                          <NavItem>
                            <NavLink
                              href='#'
                              className={classNames(
                                { active: periodType === 'monthly' },
                                'nav-link'
                              )}
                              onClick={() => {
                                onChangeChartPeriod('monthly')
                              }}
                              id='one_month'
                            >
                              {' '}
                              Month{' '}
                            </NavLink>
                          </NavItem>
                          <NavItem>
                            <NavLink
                              href='#'
                              className={classNames(
                                { active: periodType === 'yearly' },
                                'nav-link'
                              )}
                              onClick={() => {
                                onChangeChartPeriod('yearly')
                              }}
                              id='one_month'
                            >
                              {' '}
                              Year{' '}
                            </NavLink>
                          </NavItem>
                        </Nav>
                      </div>
                    </div>
                    {/* <div className="clearfix"></div> */}
                    <StackedColumnChart
                      periodData={periodData}
                      dataColors={
                        '["--bs-primary", "--bs-warning", "--bs-success"]'
                      }
                    />
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </section>
          <section>
            <div className=' p-3 pb-2' style={{ color: 'black' }}>
              <h3 className='text-2xl mb-0' style={{ fontWeight: '500' }}>
                {`All ${product.product_name} Modules`}
              </h3>
            </div>
            <DataTable<ModuleData>
              columns={columns}
              data={product?.modules || []}
              striped
              responsive
              pagination
              paginationPerPage={10}
              paginationRowsPerPageOptions={[10, 20, 30, 40]}
              paginationComponentOptions={{
                rowsPerPageText: 'Rows per page:'
              }}
              paginationTotalRows={100}
              defaultSortAsc={true}
              paginationServer={false}
              expandableRows={false}
              expandOnRowClicked={false}
              fixedHeader
              fixedHeaderScrollHeight='calc(100vh - 100px)'
              keyField='index'
              customStyles={{
                headRow: {
                  style: {
                    background: '#f2f2f2'
                  }
                },
                subHeader: {
                  style: {
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexWrap: 'nowrap'
                  }
                }
              }}
              subHeader
              subHeaderComponent={
                <>
                  <input
                    style={{ width: '400px' }}
                    type='text'
                    placeholder='Search...'
                    className='form-control me-2'
                    onChange={(e) => {
                      console.log(e.target.value)
                    }}
                  />

                  <div>
                    {' '}
                    <button
                      onClick={() => {
                        console.log('Export to CSV')
                      }}
                      className='btn  me-2 text-white '
                      style={{ background: '#74788d' }}
                    >
                      Export to CSV
                    </button>
                    <button
                      onClick={() => { navigate(`/product/${params?.id}/add-module`) }}
                      className='btn  text-white me-2'
                      style={{ background: '#74788d' }}
                    >
                      + Add Module
                    </button>
                  </div>
                </>
              }
              contextActions={<div>Edit/Delete context menu</div>}
              contextMessage={{ singular: 'item', plural: 'items' }}
              // onRowClicked={(row) => {
              //   toggleCanvas(row, 'View')
              // }}
              onSelectedRowsChange={(selectedRows) => {
                console.log(selectedRows.selectedRows)
              }}
              clearSelectedRows
              selectableRows={false} // Disable selectable rows
            />
          </section>
        </div>
      </div>
      <ActivateDeactivatePopup
      activeData={{ activeValue, name: activeData?.module_name }}
      closePopup={() => { setActivityPopupOpen(false) }}
      open={activityPopupOpen}
      submit={toggleActivation}
      />
    </React.Fragment>
  )
}

export default ViewProduct
