import React from 'react'
import { Modal, ModalHeader, ModalBody, ModalFooter, Button } from 'reactstrap'
interface deleteProdTypes {
  modal: any
  toggle: any
  id: any
}

const DeleteProd = ({ modal, toggle, id }: deleteProdTypes) => {
  console.log('id', id)

  const deleteHandle = () => {
    fetch('http://localhost:4000/api/product/delete/' + id, {
      method: 'DELETE',
      headers: {
        // "Content-Type": "application/json",
        'User-Agent': 'PostmanRuntime/7.36.0',
        Accept: '*/*',
        'Accept-Encoding': 'gzip, deflate, br',
        Connection: 'keep-alive'
      }
    }).then((res) => res.json())
    toggle()
  }

  return (
    <div>
      <Modal isOpen={modal} toggle={toggle}>
        <ModalHeader toggle={toggle}>Modal title</ModalHeader>
        <ModalBody>Sure You want to delete</ModalBody>
        <ModalFooter>
          <Button
            color='primary'
            onClick={() => {
              deleteHandle()
            }}
          >
            Do Something
          </Button>{' '}
          <Button color='secondary' onClick={toggle}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  )
}

export default DeleteProd
