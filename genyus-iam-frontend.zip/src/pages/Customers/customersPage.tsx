import React, { useEffect } from 'react'
import DataTable from 'react-data-table-component'
import {
  // FaTrashAlt,
  FaEdit
} from 'react-icons/fa'
import { useDispatch, useSelector } from 'react-redux'
import Spinners from 'Components/Common/Spinner'
import { getTenantDataThunk } from 'slices/tenant/thunk'
import { useNavigate } from 'react-router-dom'

interface CustomerData {
  index: any
  modules: any
}

const CustomersPage = () => {
  const dispatch = useDispatch<any>()
  const navigate = useNavigate()

  useEffect(() => {
    dispatch(getTenantDataThunk())
  }, [dispatch, getTenantDataThunk])

  const { tenants, loading } = useSelector((state: any) => state.Tenant)

  const columns = [
    {
      name: 'S.No.',
      selector: (row: CustomerData, index: any) => index + 1,
      sortable: true
    },
    {
      name: 'Customer Name',
      selector: (row) => {
        return <div>{row.tenant_fullname}</div>
      },
      sortable: true
    },
    {
      name: 'Customer Display Name',
      selector: (row) => {
        return <div>{row.tenant_displayname}</div>
      },
      sortable: true
    },
    {
      name: 'Email',
      selector: (row) => {
        return <div>{row.tenant_email}</div>
      },
      sortable: true
    },
    {
      name: 'Country',
      selector: (row) => {
        return <div>{row.tenant_country}</div>
      },
      sortable: true
    },
    {
      name: 'Phone',
      selector: (row) => {
        return <div>{row.tenant_phone}</div>
      },
      sortable: true
    },
    {
      name: 'Activate/Deactivate',
      selector: (row) => {
        return (
          <div className='form-check form-switch mb-3 d-flex align-items-center justify-content-center'>
            <input
              type='checkbox'
              className='form-check-input'
              id='customSwitchsizesm'
              checked={row.is_active}
              onClick={() => {
                // update api to activate/deactivate
                // toggleActivation(row)
                console.log('clicked')
              }}
            />
          </div>
        )
      },
      sortable: true
    },
    {
      name: 'Actions',
      cell: (row) => (
        <div>
          <button
            className='btn btn-secondary me-2'
            onClick={() => {
              // setEditData(row)
              // editToggle()
              console.log('Clicked')
            }}
          >
            <FaEdit />
          </button>
        </div>
      ),
      ignoreRowClick: true,
      allowOverflow: true,
      button: true
    }
  ]

  if (loading) {
    return <Spinners />
  }

  return (
    <React.Fragment>
      <div className='page-content'>
        <>
          <div className='full-page'>
            <div className=' p-3 pb-2' style={{ color: 'black' }}>
              <h3 className='text-2xl mb-0' style={{ fontWeight: '500' }}>
                Customer
              </h3>
            </div>
            <section>
              <DataTable<CustomerData>
                columns={columns}
                data={tenants}
                // data={filteredProductDetails}
                striped
                responsive
                pagination
                paginationPerPage={10}
                paginationRowsPerPageOptions={[10, 20, 30, 40]}
                paginationComponentOptions={{
                  rowsPerPageText: 'Rows per page:'
                }}
                paginationTotalRows={tenants?.length}
                defaultSortAsc={true}
                paginationServer={false}
                expandableRows={false}
                expandOnRowClicked={false}
                fixedHeader
                fixedHeaderScrollHeight='calc(100vh - 100px)'
                keyField='index'
                customStyles={{
                  headRow: {
                    style: {
                      background: '#f2f2f2'
                    }
                  },
                  subHeader: {
                    style: {
                      display: 'flex',
                      justifyContent: 'space-between',
                      flexWrap: 'nowrap'
                    }
                  }
                }}
                subHeader
                subHeaderComponent={
                  <>
                    <div className='d-flex'>
                      <input
                        style={{ width: '400px' }}
                        type='text'
                        placeholder='Search...'
                        className='form-control me-2'
                        onChange={(e) => {
                          console.log(e.target.value)
                          // (e.target.value)
                        }}
                      />
                      <div className='d-flex justify-content-between align-items-center products-retry'>
                        <i
                          className='fas fa-undo'
                          onClick={() => {
                            dispatch(getTenantDataThunk())
                          }}
                        ></i>{' '}
                      </div>
                    </div>

                    <div>
                      {' '}
                      <button
                        onClick={() => {
                          console.log('Export to CSV')
                        }}
                        className='btn  me-2 text-white '
                        style={{ background: '#74788d' }}
                      >
                        CSV Download
                      </button>
                      <button
                        onClick={() => {
                          // addToggle()
                          // setEditData({})
                          console.log('edit')
                          navigate('/customer/add')
                        }}
                        // onClick={toggleCanvas}
                        className='btn  text-white me-2'
                        style={{ background: '#74788d' }}
                      >
                        + Add Customer
                      </button>
                    </div>
                  </>
                }
                contextActions={<div>Edit/Delete context menu</div>}
                contextMessage={{ singular: 'item', plural: 'items' }}
                // onRowClicked={(row) => {
                //   toggleCanvas(row, 'View')
                // }}
                onSelectedRowsChange={(selectedRows) => {
                  console.log(selectedRows.selectedRows)
                }}
                clearSelectedRows
                selectableRows={false} // Disable selectable rows
              />
            </section>
          </div>
        </>
      </div>
    </React.Fragment>
  )
}

export default CustomersPage
