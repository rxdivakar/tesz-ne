/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable multiline-ternary */
/* eslint-disable prefer-const */
// import Spinners from 'Components/Common/Spinner'
import classnames from 'classnames'
import React, { useEffect, useState } from 'react'
// import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import {
  Button,
  // Button,
  Card,
  CardBody,
  // CardTitle,
  Col,
  Form,
  // FormGroup,
  Input,
  Label,
  NavItem,
  NavLink,
  Row,
  TabContent,
  TabPane,
  Table
} from 'reactstrap'
import { getSubscriptionDataThunk } from 'slices/subscription/thunk'
import { createTenantThunk } from 'slices/tenant/thunk'
// import { getProductDataThunk } from 'slices/product/thunk'
import Select from 'react-select'
import moment from 'moment'
import uuid from 'react-uuid'
import { createSubscribedTenantThunk } from 'slices/subscribedTenant/thunk'

interface moduleType {
  is_active: boolean
  module_id: string
  module_desc: string
  module_name: string
  module_price: string
}

interface productType {
  is_active: boolean
  product_id: string
  modules_data: moduleType[]
  product_desc: string
  product_name: string
  product_price: string
}

interface subscriptionType {
  subscription_id: string
  subscription_name: string
  subscription_type: string
  products: []
  modules: []
  product_data: productType[]
}

const AddCustomer = () => {
  const dispatch = useDispatch<any>()
  const [activeTab, setactiveTab] = useState<number>(2)
  const [passedSteps, setPassedSteps] = useState([1])

  const [createdCustomer, setCreatedCustomer] = useState({
    tenant_id: '',
    tenant_fullname: '',
    tenant_displayname: '',
    tenant_email: '',
    tenant_country: '',
    tenant_phone: '',
    is_active: true
  })

  const [customerData, setCustomerData] = useState({
    tenant_fullname: '',
    tenant_displayname: '',
    tenant_email: '',
    tenant_country: '',
    tenant_phone: '',
    is_active: true
  })

  const { loading: customerLoader, tenant } = useSelector(
    (state: any) => state.Tenant
  )

  const {
    subscriptions
    // loading
  } = useSelector((state: any) => state.Subscription)

  const [subscribedPeriod, setSubscribedPeriod] = useState(1)

  const subscriptionOptions = subscriptions.map((item) => ({
    label: item.subscription_name,
    value: item.subscription_id
  }))

  const subscriptionPeriodOptions = [
    {
      label: 'Trail',
      value: 0
    },
    {
      label: 'Monthly',
      value: 1
    },
    {
      label: 'Annually',
      value: 12
    }
  ]

  const onCustomerChange = (e) => {
    setCustomerData({ ...customerData, [e.target.name]: e.target.value })
  }

  const toggleTab = (tab: any) => {
    if (activeTab !== tab) {
      let modifiedSteps = [...passedSteps, tab]
      if (tab >= 1 && tab <= 5) {
        setactiveTab(tab)
        setPassedSteps(modifiedSteps)
      }
    }
  }

  const onCustomerSubmit = (e) => {
    e.preventDefault()
    console.log('chdece', customerData)
  }

  const [selectedSubscription, setSelectedSubscription] =
    useState<subscriptionType>({
      subscription_id: '',
      subscription_name: '',
      subscription_type: '',
      products: [],
      modules: [],
      product_data: []
    })

  const handleSubcriptionChange = (value) => {
    const found = subscriptions.find((sub) => sub.subscription_id === value)
    setSelectedSubscription(found)
  }

  const handleSubscription = () => {
    const id = uuid()
    const body = {
      subscription_id: selectedSubscription.subscription_id,
      tenant_id: createdCustomer.tenant_id,
      is_active: true,
      start_date: `${moment()}`,
      end_date:
        subscribedPeriod === 0
          ? `${moment().add(15, 'days').endOf('day')}`
          : `${moment().add(subscribedPeriod, 'months').endOf('day')}`,
      payment_id: id,
      subscription_type: subscribedPeriod
    }
    dispatch(createSubscribedTenantThunk(body))
    toggleTab(activeTab + 1)
  }

  useEffect(() => {
    setCreatedCustomer(tenant)
  }, [tenant])

  useEffect(() => {
    activeTab === 2 && dispatch(getSubscriptionDataThunk())
  }, [])

  const handleSaveAndContinue = async () => {
    if (activeTab === 1) {
      dispatch(createTenantThunk(customerData))
      !customerLoader && toggleTab(activeTab + 1)
    } else if (activeTab === 2) {
      handleSubscription()
      // toggleTab(activeTab + 1)
    }
  }
  return (
    <React.Fragment>
      <div className='page-content'>
        <div className='full-page'>
          <div className=' p-3 pb-2' style={{ color: 'black' }}>
            <h3 className='text-2xl mb-0' style={{ fontWeight: '500' }}>
              Create Customer
            </h3>
          </div>
          <section>
            <Col lg='12'>
              <Card>
                <CardBody>
                  <h4 className='card-title mb-4'>
                    Customer Activation Process{' '}
                  </h4>
                  <div className='wizard clearfix'>
                    <div className='steps clearfix'>
                      <ul>
                        <NavItem
                          className={classnames({ current: activeTab === 1 })}
                        >
                          <NavLink
                            className={classnames({ current: activeTab === 1 })}
                            onClick={() => {
                              setactiveTab(1)
                            }}
                            disabled={!(passedSteps || []).includes(1)}
                          >
                            <span className='number'>1.</span> Customer Details
                          </NavLink>
                        </NavItem>
                        <NavItem
                          className={classnames({ current: activeTab === 2 })}
                        >
                          <NavLink
                            className={classnames({ active: activeTab === 2 })}
                            onClick={() => {
                              setactiveTab(2)
                            }}
                            disabled={!(passedSteps || []).includes(2)}
                          >
                            <span className='number'>2.</span> Subscription
                            Selection
                          </NavLink>
                        </NavItem>
                        <NavItem
                          className={classnames({ current: activeTab === 3 })}
                        >
                          <NavLink
                            className={classnames({ active: activeTab === 3 })}
                            onClick={() => {
                              setactiveTab(3)
                            }}
                            disabled={!(passedSteps || []).includes(3)}
                          >
                            <span className='number'>3.</span> Billing
                          </NavLink>
                        </NavItem>

                        <NavItem
                          className={classnames({ current: activeTab === 4 })}
                        >
                          <NavLink
                            className={classnames({ active: activeTab === 4 })}
                            onClick={() => {
                              setactiveTab(4)
                            }}
                            disabled={!(passedSteps || []).includes(4)}
                          >
                            <span className='number'>4.</span> Admin Details
                          </NavLink>
                        </NavItem>

                        <NavItem
                          className={classnames({ current: activeTab === 5 })}
                        >
                          <NavLink
                            className={classnames({ active: activeTab === 5 })}
                            onClick={() => {
                              setactiveTab(4)
                            }}
                            disabled={!(passedSteps || []).includes(5)}
                          >
                            <span className='number'>5.</span> Customer
                            Confirmation
                          </NavLink>
                        </NavItem>
                      </ul>
                    </div>
                    <div className='content clearfix'>
                      <TabContent activeTab={activeTab} className='body'>
                        <TabPane tabId={1}>
                          <Form onSubmit={onCustomerSubmit}>
                            <Row>
                              <Col lg='6'>
                                <div className='mb-3'>
                                  <Label for='basicpill-firstname-input1'>
                                    Customer Name
                                  </Label>
                                  <Input
                                    type='text'
                                    className='form-control'
                                    id='basicpill-firstname-input1'
                                    placeholder='Enter Your First Name'
                                    name='tenant_fullname'
                                    value={customerData.tenant_fullname}
                                    onChange={onCustomerChange}
                                  />
                                </div>
                              </Col>
                              <Col lg='6'>
                                <div className='mb-3'>
                                  <Label for='basicpill-lastname-input2'>
                                    Customer Display Name
                                  </Label>
                                  <Input
                                    type='text'
                                    className='form-control'
                                    name='tenant_displayname'
                                    id='basicpill-lastname-input2'
                                    placeholder='Enter Your Last Name'
                                    value={customerData.tenant_displayname}
                                    onChange={onCustomerChange}
                                  />
                                </div>
                              </Col>
                            </Row>

                            <Row>
                              <Col lg='6'>
                                <div className='mb-3'>
                                  <Label for='basicpill-phoneno-input3'>
                                    Phone
                                  </Label>
                                  <Input
                                    type='text'
                                    name='tenant_phone'
                                    className='form-control'
                                    id='basicpill-phoneno-input3'
                                    placeholder='Enter Your Phone No.'
                                    value={customerData.tenant_phone}
                                    onChange={onCustomerChange}
                                  />
                                </div>
                              </Col>
                              <Col lg='6'>
                                <div className='mb-3'>
                                  <Label for='basicpill-email-input4'>
                                    Email
                                  </Label>
                                  <Input
                                    type='email'
                                    className='form-control'
                                    id='basicpill-email-input4'
                                    name='tenant_email'
                                    placeholder='Enter Your Email ID'
                                    value={customerData.tenant_email}
                                    onChange={onCustomerChange}
                                  />
                                </div>
                              </Col>
                              <Col lg='6'>
                                <div className='mb-3'>
                                  <Label for='basicpill-email-input4'>
                                    Country
                                  </Label>
                                  <Input
                                    type='email'
                                    className='form-control'
                                    id='basicpill-email-input4'
                                    name='tenant_country'
                                    placeholder='Enter Your Email ID'
                                    value={customerData.tenant_country}
                                    onChange={onCustomerChange}
                                  />
                                </div>
                              </Col>
                            </Row>
                          </Form>
                        </TabPane>
                        <TabPane tabId={2}>
                          <div>
                            <Form>
                              <Row>
                                <Col lg='6'>
                                  <div className='mb-3'>
                                    <Label for='basicpill-pancard-input5'>
                                      Customer Details
                                    </Label>
                                    <div>
                                      <p className='mb-1 pt-2'>
                                        Customer id:{' '}
                                        <span className='text-primary'>
                                          {createdCustomer.tenant_id}
                                        </span>
                                      </p>
                                      <p className='mb-1'>
                                        Customer Name:{' '}
                                        <span className='text-primary'>
                                          {createdCustomer.tenant_displayname}
                                        </span>
                                      </p>
                                      <p className='mb-1'>
                                        Email:{' '}
                                        <span className='text-primary'>
                                          {createdCustomer.tenant_email}
                                        </span>
                                      </p>
                                    </div>
                                  </div>
                                  {selectedSubscription.product_data.length >
                                    0 && (
                                    <div className='table-responsive'>
                                      <Label for='basicpill-pancard-input5'>
                                        Subscription Details
                                      </Label>
                                      <Table className='table align-middle table-nowrap'>
                                        <thead>
                                          <tr>
                                            <th scope='col'>Product</th>
                                            <th scope='col'>Modules</th>
                                            <th scope='col'>Price</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          {selectedSubscription.product_data.map(
                                            (product: productType, index) => {
                                              return (
                                                <tr key={index}>
                                                  <th scope='row'>
                                                    <div>
                                                      {product.product_name}
                                                    </div>
                                                  </th>
                                                  <td>
                                                    <div>
                                                      <div>
                                                        {product.modules_data.map(
                                                          (
                                                            mod: moduleType,
                                                            index
                                                          ) => {
                                                            return (
                                                              <>
                                                                <div
                                                                  key={index}
                                                                >
                                                                  <h5 className='text-truncate font-size-14'>
                                                                    {
                                                                      mod.module_name
                                                                    }
                                                                  </h5>
                                                                </div>
                                                                <p className='text-muted mb-0'>
                                                                  $ 10 x{' '}
                                                                  {
                                                                    subscribedPeriod
                                                                  }
                                                                </p>
                                                              </>
                                                            )
                                                          }
                                                        )}
                                                      </div>
                                                    </div>
                                                  </td>
                                                  <td>
                                                    ${' '}
                                                    {product?.modules_data
                                                      ?.length *
                                                      10 *
                                                      Number(subscribedPeriod)}
                                                  </td>
                                                </tr>
                                              )
                                            }
                                          )}
                                          <tr>
                                            <td colSpan={2}>
                                              <h6 className='m-0 text-right'>
                                                Sub Total:
                                              </h6>
                                            </td>
                                            <td>
                                              {selectedSubscription.modules
                                                .length *
                                                10 *
                                                subscribedPeriod}
                                            </td>
                                          </tr>
                                          <tr>
                                            <td colSpan={2}>
                                              <h6 className='m-0 text-right'>
                                                Total:
                                              </h6>
                                            </td>
                                            <td>
                                              {selectedSubscription.modules
                                                .length *
                                                10 *
                                                subscribedPeriod}
                                            </td>
                                          </tr>
                                        </tbody>
                                      </Table>
                                    </div>
                                  )}
                                </Col>

                                <Col lg='4'>
                                  <div className='mb-3'>
                                    <Label for='basicpill-pancard-input5'>
                                      Subscriptions
                                    </Label>
                                    <Col sm={12}>
                                      <Select
                                        id='show'
                                        name='show'
                                        // isMulti={true}
                                        placeholder='Select Subscription'
                                        options={subscriptionOptions}
                                        onChange={(value: any) => {
                                          handleSubcriptionChange(value.value)
                                        }}
                                        classNamePrefix='mySelect'
                                      />
                                    </Col>
                                  </div>
                                  <div className='mb-3'>
                                    <Label for='basicpill-pancard-input5'>
                                      Subscription Period
                                    </Label>
                                    <Col sm={12}>
                                      <Select
                                        id='show'
                                        name='show'
                                        // isMulti={true}
                                        placeholder='Select Subscription Period'
                                        options={subscriptionPeriodOptions}
                                        defaultValue={{
                                          label: 'Monthly',
                                          value: 1
                                        }}
                                        onChange={(value: any) => {
                                          setSubscribedPeriod(value.value)
                                        }}
                                        classNamePrefix='mySelect'
                                      />
                                    </Col>
                                  </div>
                                </Col>
                              </Row>
                            </Form>
                          </div>
                        </TabPane>
                        <TabPane tabId={3}>
                          <div>
                            <Form>
                              <Row>
                                <Col lg='6'>
                                  <div className='mb-3'>
                                    <Label for='basicpill-namecard-input11'>
                                      Name on Card
                                    </Label>
                                    <Input
                                      type='text'
                                      name='card'
                                      className='form-control'
                                      id='basicpill-namecard-input11'
                                      placeholder='Enter Your Name on Card'
                                      // value={wizardformik.values.card}
                                      // onChange={wizardformik.handleChange}
                                      // onBlur={wizardformik.handleBlur}
                                    />
                                  </div>
                                </Col>

                                <Col lg='6'>
                                  <div className='mb-3'>
                                    <Label>Credit Card Type</Label>
                                    <select
                                      className='form-select'
                                      name='creditcard'
                                      // value={wizardformik.values.creditcard}
                                      // onChange={wizardformik.handleChange}
                                      // onBlur={wizardformik.handleBlur}
                                    >
                                      <option>Select Card Type</option>
                                      <option value='AE'>
                                        American Express
                                      </option>
                                      <option value='VI'>Visa</option>
                                      <option value='MC'>MasterCard</option>
                                      <option value='DI'>Discover</option>
                                    </select>
                                  </div>
                                </Col>
                              </Row>
                              <Row>
                                <Col lg='6'>
                                  <div className='mb-3'>
                                    <Label for='basicpill-cardno-input12'>
                                      Credit Card Number
                                    </Label>
                                    <Input
                                      type='text'
                                      name='creditno'
                                      className='form-control'
                                      id='basicpill-cardno-input12'
                                      placeholder='Credit Card Number'
                                    />
                                  </div>
                                </Col>

                                <Col lg='6'>
                                  <div className='mb-3'>
                                    <Label for='basicpill-card-verification-input0'>
                                      Card Verification Number
                                    </Label>
                                    <Input
                                      type='text'
                                      className='form-control'
                                      name='cardvarification'
                                      id='basicpill-card-verification-input0'
                                      placeholder='Credit Verification Number'
                                      // value={
                                      //   wizardformik.values.cardvarification
                                      // }
                                      // onChange={wizardformik.handleChange}
                                      // onBlur={wizardformik.handleBlur}
                                    />
                                  </div>
                                </Col>
                              </Row>
                              <Row>
                                <Col lg='6'>
                                  <div className='mb-3'>
                                    <Label for='basicpill-expiration-input13'>
                                      Expiration Date
                                    </Label>
                                    <Input
                                      type='text'
                                      name='expiratdata'
                                      className='form-control'
                                      id='basicpill-expiration-input13'
                                      placeholder='Card Expiration Date'
                                      // value={wizardformik.values.expiratdata}
                                      // onChange={wizardformik.handleChange}
                                      // onBlur={wizardformik.handleBlur}
                                    />
                                  </div>
                                </Col>
                              </Row>
                            </Form>
                          </div>
                        </TabPane>
                        <TabPane tabId={4}>
                          <div className='row justify-content-center'>
                            <Col lg='6'>
                              <div className='text-center'>
                                <div className='mb-4'>
                                  <i className='mdi mdi-check-circle-outline text-success display-4' />
                                </div>
                                <div>
                                  <h5>Confirm Detail</h5>
                                  <p className='text-muted'>
                                    If several languages coalesce, the grammar
                                    of the resulting
                                  </p>
                                </div>
                              </div>
                            </Col>
                          </div>
                        </TabPane>
                      </TabContent>
                    </div>
                    <div className='actions clearfix'>
                      <ul>
                        <li>
                          <Button
                            color='primary'
                            className='w-md'
                            onClick={handleSaveAndContinue}
                          >
                            Save and Continue
                          </Button>
                        </li>
                        <li>
                          <Button color='secondary' className='ms-1 w-md'>
                            Cancel
                          </Button>
                          {/* <Link
                            to='#'
                            onClick={() => {
                              toggleTab(activeTab + 1)
                            }}
                          >
                            Save and Continue
                          </Link> */}
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </Col>
          </section>
        </div>
      </div>
    </React.Fragment>
  )
}

export default AddCustomer
