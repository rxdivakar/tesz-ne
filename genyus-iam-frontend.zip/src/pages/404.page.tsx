import React from 'react'
import SeebreaseLogo from '../assets/icons/darkBoteLogo.svg'
import { Link } from 'react-router-dom'

const PageNotFound = () => {
  return (
    <React.Fragment>
      <div style={{ minHeight: '100vh', background: '#F4EFE9' }}>
        <div className='py-5 px-2 d-flex flex-column justify-content-center align-items-center text-center'>
            <div>
                <img src={SeebreaseLogo} alt='test' height={250}/>
            </div>
            <p className='h1 fw-bold my-3'>Oops! Something went wrong!</p>
            <p className='fs-4'>Please either refresh the page or return home to try again</p>
            <Link to={'/'} className='back-to-home mt-3'>Back To Home</Link>
        </div>
      </div>
    </React.Fragment>
  )
}

export default PageNotFound
