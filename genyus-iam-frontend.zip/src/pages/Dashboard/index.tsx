import React from 'react'
import DashboardPage from './dashboard-page'

const Dashboard = () => {
  return (
    <React.Fragment>
          <DashboardPage />
    </React.Fragment>
  )
}

export default Dashboard
