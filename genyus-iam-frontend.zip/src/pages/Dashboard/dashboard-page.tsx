import React from 'react'
import { Col, Row } from 'reactstrap'
// import CardWelcome from 'pages/Products/card-welcome'
import CardUser from 'pages/Products/card-user'
import MiniWidget from './mini-widgets'
import Earning from './earning'
import SalesAnalytics from './sales-analytics'
import TotalSellingProduct from './total-selling-product'

const DashboardPage = () => {
  const reports = [
    {
      icon: 'bx bx-copy-alt',
      title: 'Orders',
      value: '1,452 ',
      badgeValue: '+ 0.2%',
      color: 'success',
      desc: 'From previous period'
    },
    {
      icon: 'bx bx-archive-in',
      title: 'Revenue',
      value: '$ 28,452 ',
      badgeValue: '+ 0.2%',
      color: 'success',
      desc: 'From previous period'
    },
    {
      icon: 'bx bx-purchase-tag-alt',
      title: 'Average Price',
      value: '$ 16.2 ',
      badgeValue: '0%',
      color: 'warning',
      desc: 'From previous period'
    }
  ]
  return (
    <React.Fragment>
      <div className='page-content'>
        <div className='pb-2' style={{ color: 'black' }}>
          <h3 className='text-2xl mb-0 p-1' style={{ fontWeight: '500' }}>
            Home Dashboard
          </h3>
          <section className='m-1 pt-1'>
            <CardUser />
            <Row>
              {/* <CardWelcome /> */}
              <Col xl={12}>
                <Row>
                  <MiniWidget reports={reports} />
                </Row>
              </Col>
            </Row>
            <Row>
              <Earning dataColors='["--bs-primary"]' />
              <SalesAnalytics dataColors='["--bs-primary", "--bs-success", "--bs-danger"]' />
            </Row>

            <Row>
              {/* total selling product */}
              <TotalSellingProduct />
            </Row>
          </section>
        </div>
      </div>
    </React.Fragment>
  )
}

export default DashboardPage
