import React from 'react'
import DataTable from 'react-data-table-component'
import { Col, Container, Label, Row } from 'reactstrap'
import activitylog from '../../assets/images/activitylog.png'
import bookmark from '../../assets/images/bookmark.png'
import dashboardProfile from '../../assets/images/dashboard-profile.jpg'
import followups from '../../assets/images/followups.png'
import jumpto from '../../assets/images/jumpto.png'
import myclaimremainder from '../../assets/images/myclaimsreminder.png'

const DashboardDesign = () => {
  const columns = [
    {
      name: 'Claim#',
      selector: row => row.claim
    },
    {
      name: 'Patient Code',
      selector: row => row.patientcode
    },
    {
      name: 'Patient Name',
      selector: row => row.patientname
    },
    {
      name: 'Remainder Date',
      selector: row => row.remainderdate
    },
    {
      name: 'Remainder Notes',
      selector: row => row.remaindernotes
    },
    {
      name: 'Due In',
      selector: row => row.duein
    },
    {
      name: 'Action',
      selector: row => row.action
    }
  ]

  const data = [
    {
      claim: 'Claim#',
      patientcode: 'Patient Code',
      patientname: 'Patient Name',
      remainderdate: 'Remainder Date',
      remaindernotes: 'Remainder Notes',
      duein: 'Due In',
      action: 'Action'
    },
    {
      claim: 'Claim#',
      patientcode: 'Patient Code',
      patientname: 'Patient Name',
      remainderdate: 'Remainder Date',
      remaindernotes: 'Remainder Notes',
      duein: 'Due In',
      action: 'Action'
    },
    {
      claim: 'Claim#',
      patientcode: 'Patient Code',
      patientname: 'Patient Name',
      remainderdate: 'Remainder Date',
      remaindernotes: 'Remainder Notes',
      duein: 'Due In',
      action: 'Action'
    }
  ]
  return (
    <React.Fragment>
      <Container className='p-0'>
        <Row className='mb-4'>
        <Col className='shadow-lg border dashboard-col1' style={{ borderRadius: '15px', backgroundColor: 'white' }}>
          <h6 className='dashboard-h1 p-3'>My Dashboard</h6>
        <Row className='shadow-lg' style={{ backgroundColor: 'white', borderRadius: '10px' }}>
          <Col className='col-2' style={{ borderBottomLeftRadius: '10px' }}>
            <img src={dashboardProfile} alt="" className="img-fluid dashboard-profile"/>
          </Col>
        <Col style={{ borderBottomRightRadius: '10px' }}>
        <div>
        <button className="shadow-lg border rounded justify-content-start dashboard-btn" style={{ backgroundColor: 'whitesmoke', width: '90px', height: '40px', marginRight: '4px', fontSize: '10px', marginLeft: '10px', borderWidth: '0.6px', borderColor: '#ccc' }}><img src={jumpto} alt='' style={{ height: '15px', width: '15px', marginRight: '5px' }} /> Jump to</button>
        <button className="shadow-lg rounded border dashboard-btn" style={{ backgroundColor: 'whitesmoke', width: '120px', height: '40px', marginRight: '4px', fontSize: '10px', borderWidth: '0.6px', borderColor: '#ccc' }}> <img src={bookmark} alt='' style={{ height: '15px', width: '15px', marginRight: '5px' }} /> My Bookmark</button>
        <button className="shadow-lg rounded border dashboard-btn" style={{ backgroundColor: 'whitesmoke', width: '120px', height: '40px', marginRight: '4px', fontSize: '10px', borderWidth: '0.6px', borderColor: '#ccc' }}> <img src={activitylog} alt='' style={{ height: '15px', width: '15px', marginRight: '5px' }} /> My Activity Log</button>
        <button className="shadow-lg rounded border dashboard-btn" style={{ backgroundColor: 'whitesmoke', width: '170px', height: '40px', fontSize: '10px', marginRight: '4px', borderWidth: '0.6px', borderColor: '#ccc' }}> <img src={myclaimremainder} alt='' style={{ height: '15px', width: '15px', marginRight: '5px' }} /> My Claim Remainder(s)</button>
        <button className="shadow-lg rounded border dashboard-btn" style={{ backgroundColor: 'whitesmoke', width: '150px', height: '40px', marginTop: '20px', fontSize: '10px', borderWidth: '0.6px', borderColor: '#ccc', marginLeft: '10px' }}> <img src={followups} alt='' style={{ height: '15px', width: '15px', marginRight: '5px' }} /> My Claim Followup</button>
        </div>
        </Col>
        </Row>
        </Col>
        <Col md={8} lg={6} xl={5} className='shadow-lg border' style={{ height: '145px', backgroundColor: '#fff', border: '1px solid white', borderTopLeftRadius: '10px', borderTopRightRadius: '10px', borderRadius: '10px' }}>
          <h6 className='p-3 dashboard-h2'> &nbsp; My Claims Remainder</h6>
        <Row className='p-2'>
          <Col className='border rounded shadow-lg' style={{ height: '40px', fontSize: '11px', width: '110px', marginRight: '5px', color: 'black' }}>
            <input style={{ marginRight: '5px' }} type='radio' />
            <Label className='mt-3'>Past Dues</Label>
          </Col>
          <Col className='border rounded shadow-lg' style={{ height: '40px', fontSize: '11px', width: '110px', marginRight: '5px', color: 'black' }}>
            <input style={{ marginRight: '5px' }} type='radio' />
            <Label className='mt-3'>Future Dues</Label>
          </Col>
          <Col className='border rounded shadow-lg' style={{ height: '40px', fontSize: '11px', width: '110px', marginRight: '5px', color: 'black' }}>
            <input style={{ marginRight: '5px' }} type='radio' />
            <Label className='mt-3'>Due Today</Label>
          </Col>
          <Col className='border rounded shadow-lg' style={{ height: '40px', fontSize: '11px', width: '110px', marginRight: '5px', color: 'black' }}>
            <input style={{ marginRight: '5px' }} type='radio' />
            <Label className='mt-3'>All</Label>
          </Col>
        </Row>
        </Col>
        </Row>
        </Container>
        <div className='dashboard-table' style={{ paddingLeft: '15px', paddingRight: '15px', width: '100%', textAlign: 'center', alignItems: 'center' }}>
        <DataTable
          columns={columns}
          data={data}
          responsive
          fixedHeader
          pagination
          ></DataTable>
          </div>
    </React.Fragment>
  )
}

export default DashboardDesign
